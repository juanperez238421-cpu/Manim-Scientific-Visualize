// Numerical QA of the physics shown in the film: writes qa/physics_qa.json, exits 1 on failure.
//  1. closed forms: T, v(T) and the case-3 apex satisfy y(T) = 0, v = v0 − gT, v² = v0² + 2gh
//  2. the skull drawn in the film: at EVERY drawing of every flight its centre of mass equals the
//     analytic y(τ) (tolerance 1e-9 m) on the vertical line x = 0.25 m; finite differences of the
//     drawn positions give v(τ) and a = −g
//  3. hand-off: at release the held skull is at (0.25 m, 45 m) moving at exactly v0 (C1 continuity)
//  4. the impact falls on a drawing of the film (frame-exact sound and picture)
//  5. the rewind retraces the same path (time-reversed): positions equal y(T − 5 s')
//  6. rig sanity on every drawing: rotations orthonormal, bone lengths exact, no IK clamp
import fs from 'node:fs';
import path from 'node:path';
import { makeBones, XREL, K } from '../lib/bones.js';
import { CASES, H, G, y as yOf, v as vOf, solve } from '../lib/physics.js';
import { DIM } from '../../../halloween-hop/rig/model.js';
import { mm, tr, det, dist } from '../../../halloween-hop/lib/m3.js';

const here = path.dirname(new URL(import.meta.url).pathname);
const tl = JSON.parse(fs.readFileSync(path.join(here, '../timeline.json')));
const B = makeBones(tl);
const derived = JSON.parse(fs.readFileSync(path.join(here, '../../shared/derived.json')));
const dps = tl.music.drawingsPerSecond, fps = tl.project.fps;
const rep = { cases: [], rig: {}, checks: {} };
let ok = true;
const near = (a, b, tol) => Math.abs(a - b) <= tol;

for (const cs of B.cases) {
  const c = cs.phys, r = { id: c.id, v0: c.v0, T: c.T, vImpact: c.vImpact };
  // 1. closed forms
  r.closedForm = {
    yT: yOf(c, c.T), vT_minus: c.vImpact - (c.v0 - G * c.T), energy: c.vImpact ** 2 - (c.v0 ** 2 + 2 * G * H),
    ...(c.v0 > 0 ? { vApex: vOf(c, c.tApex), yApex: yOf(c, c.tApex), yBack: yOf(c, c.tBack), vBack: vOf(c, c.tBack) } : {}),
  };
  const cf = Math.abs(r.closedForm.yT) < 1e-12 && Math.abs(r.closedForm.vT_minus) < 1e-12 && Math.abs(r.closedForm.energy) < 1e-9
    && (c.v0 <= 0 || (Math.abs(r.closedForm.vApex) < 1e-12 && near(r.closedForm.yApex, 50, 1e-12) && near(r.closedForm.yBack, 45, 1e-12) && near(r.closedForm.vBack, -10, 1e-12)));
  // 2. the drawn skull at every drawing of the flight
  const k0 = Math.ceil(cs.release * dps - 1e-9), k1 = Math.floor(cs.impact * dps + 1e-9);
  let maxErr = 0, maxX = 0, n = 0;
  const ys = [];
  for (let k = k0; k <= k1; k++) {
    const td = k / dps;
    const sk = B.state(td).skull;
    if (sk.mode !== 'free' && !(sk.mode === 'ground' && k === k1)) continue;
    const w = B.toWorld(sk.cm);
    const tau = td - cs.release;
    const yy = sk.mode === 'ground' ? 0 : yOf(c, tau);
    maxErr = Math.max(maxErr, Math.abs(w[1] - yy)); maxX = Math.max(maxX, Math.abs(w[0] - XREL)); n++;
    ys.push([tau, w[1]]);
  }
  // finite differences on the drawn positions (exact for a parabola: central differences)
  let maxV = 0, maxA = 0;
  for (let i = 1; i + 1 < ys.length - 1; i++) {
    const h = ys[i + 1][0] - ys[i][0];
    const vfd = (ys[i + 1][1] - ys[i - 1][1]) / (2 * h), afd = (ys[i + 1][1] - 2 * ys[i][1] + ys[i - 1][1]) / (h * h);
    maxV = Math.max(maxV, Math.abs(vfd - vOf(c, ys[i][0]))); maxA = Math.max(maxA, Math.abs(afd + G));
  }
  r.drawn = { drawings: n, maxYErr_m: maxErr, maxXErr_m: maxX, maxVErr_mps: maxV, maxAErr_mps2: maxA };
  // 3. release hand-off: held path just before release (1e-4 s) and flight just after
  const e = 1e-4;
  const sk = (t) => B.state(t).skull;
  const before = B.toWorld(sk(cs.release - e).cm), at = B.toWorld(sk(cs.release).cm), after = B.toWorld(sk(cs.release + e).cm);
  const vxBefore = (at[0] - before[0]) / e;
  r.release = { pos: at, vBefore: (at[1] - before[1]) / e, vxBefore, vAfter: (after[1] - at[1]) / e };
  const relOk = near(at[0], XREL, 1e-9) && near(at[1], H, 1e-9) && near(r.release.vBefore, c.v0, 0.02) && near(r.release.vAfter, c.v0, 0.02) && Math.abs(vxBefore) < 0.02;
  // cross-check against the Python verification (same constants, same closed forms)
  const dp = derived.cases[String(c.id)];
  r.crossCheck = { T: c.T - dp.T, v: c.vImpact - dp.v_impact };
  const xOk = Math.abs(r.crossCheck.T) < 1e-12 && Math.abs(r.crossCheck.v) < 1e-12;
  if (cs.sl) {
    const sl = cs.sl;
    r.sling = { omega: sl.omega, R: sl.R, vRelease: sl.omega * sl.R, thetaAtRelease_mod2pi: ((sl.theta(cs.release) % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI), thetaDotRelease: sl.thetaDot(cs.release), stopsAt: sl.tStop, derivedOmega: derived.sling.omega };
  }
  // 4. impact on a drawing and on a frame
  r.impact = { t: cs.impact, frame: cs.impact * fps, drawing: cs.impact * dps, release: cs.release, T_check: cs.impact - cs.release - c.T };
  const impOk = near(r.impact.drawing, Math.round(r.impact.drawing), 1e-9) && Math.abs(r.impact.T_check) < 1e-9;
  // 5. rewind retraces the flight
  const rw0 = cs.react[0] + 1.0;
  let maxRw = 0;
  for (let k = Math.ceil(rw0 * dps); k / dps < rw0 + c.T / 5; k++) {
    const td = k / dps, sk = B.state(td).skull;
    if (sk.mode !== 'rewind') continue;
    const tau = Math.max(0, c.T - 5 * (td - rw0));
    maxRw = Math.max(maxRw, Math.abs(B.toWorld(sk.cm)[1] - yOf(c, tau)));
  }
  r.rewindMaxErr_m = maxRw;
  r.pass = xOk && (!cs.sl || (Math.abs(r.sling.vRelease - 10) < 1e-12 && Math.min(r.sling.thetaAtRelease_mod2pi, 2 * Math.PI - r.sling.thetaAtRelease_mod2pi) < 1e-9 && Math.abs(r.sling.omega - r.sling.derivedOmega) < 1e-12)) && cf && maxErr < 1e-9 && maxX < 1e-9 && maxV < 1e-6 && maxA < 1e-6 && relOk && impOk && maxRw < 1e-9 && n > 10;
  ok &&= r.pass;
  rep.cases.push(r);
}
// 6. rig sanity over the whole film (every drawing)
let maxOrtho = 0, maxLen = 0, clamps = [];
const N = Math.round(tl.project.duration * dps);
for (let k = 0; k <= N; k++) {
  const td = k / dps;
  const p = B.pose(td);
  for (const F of Object.values(p.ev.fr)) {
    if (!F || !F.R) continue;
    const E = mm(tr(F.R), F.R); for (let i = 0; i < 9; i++) maxOrtho = Math.max(maxOrtho, Math.abs(E[i] - (i % 4 === 0 ? 1 : 0)));
    maxOrtho = Math.max(maxOrtho, Math.abs(det(F.R) - 1));
  }
  const J = p.ev.J;
  for (const n of ['L', 'R']) {
    const hum = J[`detached${n}`] ? dist(p.ev.fr[`hum${n}`].t, J[`elbow${n}`]) : dist(J[`shoulder${n}`], J[`elbow${n}`]); // detached: from its own humeral head
    maxLen = Math.max(maxLen, Math.abs(dist(J[`hip${n}`], J[`knee${n}`]) - DIM.femur), Math.abs(dist(J[`knee${n}`], J[`ankle${n}`]) - DIM.tibia),
      Math.abs(hum - DIM.humerus), Math.abs(dist(J[`elbow${n}`], J[`wrist${n}`]) - DIM.forearm));
  }
  for (const f of p.ev.flags.ik) if (!f.reach) clamps.push({ limb: f.limb, t: +td.toFixed(3), over: +f.over.toFixed(2) });
}
rep.rig = { drawings: N + 1, maxOrthoErr: maxOrtho, maxBoneLenErr_u: maxLen, ikClamps: clamps.length, firstClamps: clamps.slice(0, 20), uPerMetre: K };
const rigOk = maxOrtho < 1e-9 && maxLen < 1e-6 && clamps.length === 0;
rep.checks = { physics: rep.cases.every((r) => r.pass), rig: rigOk };
rep.pass = ok && rigOk;
rep.solveCheck = CASES.map((c) => ({ id: c.id, T: solve(c.v0).T }));
fs.writeFileSync(path.join(here, '../../qa/cartoon_physics_qa.json'), JSON.stringify(rep, null, 1));
console.log(JSON.stringify({ checks: rep.checks, pass: rep.pass, cases: rep.cases.map((r) => ({ id: r.id, T: r.T, drawn: r.drawn, release: r.release, sling: r.sling, cross: r.crossCheck, rewind: r.rewindMaxErr_m, pass: r.pass })), rig: { ...rep.rig, firstClamps: rep.rig.firstClamps.slice(0, 8) } }, null, 1));
process.exit(rep.pass ? 0 : 1);
