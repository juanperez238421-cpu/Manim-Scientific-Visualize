import fs from 'node:fs';
import { makeBones } from '../lib/bones.js';
import { dist } from '../../../halloween-hop/lib/m3.js';
const tl = JSON.parse(fs.readFileSync(new URL('../timeline.json', import.meta.url)));
const t0 = Date.now();
const B = makeBones(tl);
console.log('built', Date.now() - t0, 'ms', 'SH_L', B.SH_L.map((x) => x.toFixed(0)).join(','), 'C', B.C_SLING.join(','));
const ts = process.argv.slice(2).map(Number);
for (const t of ts) {
  const p = B.pose(t);
  const ik = p.ev.flags.ik.filter((f) => !f.reach).map((f) => `${f.limb}+${f.over.toFixed(1)}`).join(' ');
  const sk = p.skull;
  const hand = p.ev.fr.handL ? p.ev.fr.handL.t : null;
  console.log(t.toFixed(3), sk.mode, 'cm', sk.cm ? sk.cm.map((x) => x.toFixed(0)).join(',') : '-', 'IK', ik || 'ok', 'wristR', p.ev.J.wristR.map((x) => x.toFixed(0)).join(','), 'wristL', p.ev.J.wristL.map((x) => x.toFixed(0)).join(','), sk.cm && hand ? 'hand-cm ' + dist(hand, sk.cm).toFixed(0) : '');
}
