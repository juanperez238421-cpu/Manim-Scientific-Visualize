// Mr. Bones · free fall — HYBRID cartoon engine, ENGLISH edition (g = 9.81 m/s²) (1920x1080, 30 fps, drawings on twos = 15/s).
// Five clips (prologue, case 1, case 2 with the sling, case 3 with the sling, finale); each one opens
// from and closes to a pure #FFFFFF frame so it cuts invisibly against the ManimCE lesson.
// Overlays follow the shared design tokens (Noto Serif; C_POS position, C_VEL velocity, C_ACC
// acceleration/gravity, C_GAL verified result); every number comes from lib/physics.js.
import { makeClock, prog, lerp, easeOut, easeIn, easeInOut, smooth, backOut } from '../../halloween-hop/lib/clock.js';
import { makeInk, G } from '../../halloween-hop/lib/ink.js';
import { makeFilm } from '../../halloween-hop/lib/film.js';
import { drawMoon, drawBat } from '../../halloween-hop/chars/spooks.js';
import { makeBoneRenderer } from '../../halloween-hop/rig/render.js';
import { costumeItems } from '../../halloween-hop/rig/costume.js';
import { makeBones, K, X0, XREL } from './lib/bones.js';
import { H, G as GRAV, CASES, y as yOf, v as vOf, fmt, strobeTimes } from './lib/physics.js';
import { drawCitySky, drawSkyline, drawBuilding, drawGround, drawRuler, arrow, sp, sy } from './lib/sets.js';
import { mathLine, mathReveal, mathWidth } from './lib/text.js';

const TOK = { BG: '#FFFFFF', INK: '#151515', MUTED: '#6E6E6E', RULE: '#D6D6D6', FILL: '#F3F3F3', STROKE: '#3C3C3C', ACC: '#B03A2E', VEL: '#B7791F', POS: '#2C6E9B', GAL: '#2F7D5B' };
const SERIF = 'Noto Serif';

async function boot() {
  const tl = await fetch('./timeline.json').then((r) => r.json());
  await Promise.all([document.fonts.load(`400 40px "${SERIF}"`), document.fonts.load(`700 40px "${SERIF}"`), document.fonts.load(`italic 400 40px "${SERIF}"`)]);
  await document.fonts.ready;
  const W = tl.project.width, Hh = tl.project.height, FPS = tl.project.fps;
  const C = makeClock(tl);
  const S = tl.scenes;
  const out = document.getElementById('film');
  const octx = out.getContext('2d', { willReadFrequently: true });
  const cel = document.createElement('canvas');
  cel.width = W; cel.height = Hh;
  const celCtx = cel.getContext('2d', { willReadFrequently: true });
  let ctx = celCtx; // switched to the output canvas while the crisp overlays are drawn
  const ink = makeInk(celCtx, tl.project.seed);
  let post = []; // overlay painters, run after the film look (annotations stay crisp)
  const later = (fn) => post.push(fn);
  const laterClip = (x, y, w, h, fn) => post.push(() => { ctx.save(); ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip(); fn(); ctx.restore(); });
  const film = makeFilm(W, Hh, tl.project.seed);
  const BONES = makeBones(tl);
  const drawBones = makeBoneRenderer(tl.project.seed ^ 0x5b0e);
  const isHead = (d) => d.frame === 'head' || d.frame === 'jaw';

  // ------------------------------------------------------------------ cameras
  const rigView = (cam) => ({ x0: cam.cx + (X0 - cam.wx) * cam.s, y0: cam.cy + (cam.wy - H) * cam.s, S: cam.s / K, pitch: 0 });
  const ROOF_CAM = { wx: -0.25, wy: 45.55, s: 290, cx: 900, cy: 540 };
  const PANEL_X = 700;
  const WIDE = { wx: -3.6, wy: 25.4, s: 18.6, cx: 360, cy: 560 };

  function skeletonInCam(cam, p, opts = {}) {
    const view = rigView(cam);
    const proj = (q) => [view.x0 + view.S * q[0], view.y0 - view.S * q[1], q[2]];
    const { items } = costumeItems(ink, p.ev, p.c, p.sec, proj, view.S);
    drawBones(ctx, BONES.model, p.ev, p.c, view, p.drawIndex, { extras: opts.noCostume ? [] : items, filter: opts.filter });
  }
  function skullInCam(cam, p, mag = 1) {
    const sk = p.skull;
    const [X, Y] = sp(cam, ...BONES.toWorld(sk.cm));
    const S2 = (cam.s / K) * mag;
    drawBones(ctx, BONES.model, p.ev, p.c, { x0: X - S2 * sk.cm[0], y0: Y + S2 * sk.cm[1], S: S2, pitch: 0 }, p.drawIndex, { filter: isHead });
    return [X, Y];
  }

  // ------------------------------------------------------------------ design-token overlays
  const font = (px, w = 400, it = false) => `${it ? 'italic ' : ''}${w} ${px}px "${SERIF}"`;
  function card(x, y, w, h, { border = TOK.RULE, fill = TOK.BG, lw = 2 } = {}) {
    ctx.save();
    ctx.fillStyle = fill; ctx.globalAlpha = 0.96; ctx.fillRect(x, y, w, h); ctx.globalAlpha = 1;
    ctx.strokeStyle = border; ctx.lineWidth = lw; ctx.strokeRect(x, y, w, h);
    ctx.restore();
  }
  function text(str, x, y, px, color = TOK.INK, { w = 400, align = 'left', it = false } = {}) {
    ctx.font = font(px, w, it); ctx.fillStyle = color; ctx.textAlign = align; ctx.textBaseline = 'alphabetic';
    ctx.fillText(str, x, y); ctx.textAlign = 'left';
  }
  const math = (src, x, y, px, color = TOK.INK) => mathLine(ctx, src, x, y, px, { font: SERIF, fill: color, stroke: null });
  const mathW = (src, px) => mathWidth(ctx, src, px, SERIF);
  // chapter caption (engine-B anatomy): numbered box · bold uppercase title · grey subtitle · rule
  function chapter(num, title, sub) {
    const x = 60, y = 40;
    card(x, y, 980, 112, { border: TOK.RULE });
    ctx.fillStyle = TOK.INK; ctx.fillRect(x + 18, y + 18, 76, 76);
    text(num, x + 56, y + 70, 36, TOK.BG, { w: 700, align: 'center' });
    text(title.toUpperCase(), x + 116, y + 58, 32, TOK.INK, { w: 700 });
    text(sub, x + 116, y + 94, 22, TOK.MUTED);
  }
  function note(str) { // grey italic source note, bottom left
    card(52, Hh - 62, mathW(str, 20) + 40, 40, { border: TOK.RULE });
    text(str, 72, Hh - 34, 20, TOK.MUTED, { it: true });
  }
  const vStr = (v) => `${fmt(Math.abs(v), 1)} m/s ${Math.abs(v) < 0.05 ? '' : v < 0 ? '\\down' : '\\up'}`;

  function background(cam, t) {
    drawCitySky(ink, W, Hh, t, cam);
    drawMoon(ink, { x: 1560 - (cam.wx + 0.35) * 2, y: 180 + (cam.wy - 45) * 1.2, r: 96, look: [-0.4, 0.4], sleepy: 0 });
    drawSkyline(ink, cam, W, 0.16);
  }
  function roofScene(td, di, cam = ROOF_CAM) {
    background(cam, td);
    drawGround(ink, cam, W, Hh);
    drawBuilding(ink, cam, { t: td });
    const p = { ...BONES.pose(td), drawIndex: di };
    skeletonInCam(cam, p);
    return { cam, p };
  }

  // ------------------------------------------------------------------ the sling overlay (roof camera)
  function slingOverlay(cam, p, cs, td) {
    const sl = cs.sl;
    if (!sl || td < cs.hang || td > cs.release + 0.9) return;
    const [cx, cy] = sp(cam, ...BONES.toWorld(BONES.C_SLING));
    const Rpx = sl.R * cam.s;
    ctx.save();
    ctx.setLineDash([10, 9]); ctx.strokeStyle = TOK.POS; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(cx, cy, Rpx, 0, 2 * Math.PI); ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle = TOK.POS; ctx.beginPath(); ctx.arc(cx, cy, 7, 0, 2 * Math.PI); ctx.fill();
    // the release point: the radius is horizontal there, so the velocity is vertical
    const [rx, ry] = [cx + Rpx, cy];
    ctx.strokeStyle = TOK.GAL; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(rx, ry); ctx.stroke();
    ctx.restore();
    math(`R = ${fmt(sl.R, 3)} m`, cx + Rpx * 0.25, cy - 14, 26, TOK.POS);
    // live angular speed and tangential speed
    const w = Math.abs(sl.thetaDot(td)), v = w * sl.R;
    card(1330, 210, 540, 190, { border: TOK.RULE });
    text('SLING (Mr. Bones\' own arm)', 1352, 248, 24, TOK.INK, { w: 700 });
    math(`ω = ${fmt(w, 1)} rad/s`, 1352, 296, 30, TOK.INK);
    math(`v = ω R = ${fmt(v, 1)} m/s`, 1352, 344, 30, TOK.VEL);
    text(td < cs.release ? (td < sl.tS + 0.8 ? 'spinning up (constant α)' : 'constant ω · lets go at the green mark') : 'released! it leaves vertically', 1352, 386, 22, TOK.MUTED, { it: true });
    // tangential velocity arrow on the skull while it is in the sling
    if (p.skull.mode === 'sling' && w > 0.5) {
      const th = sl.theta(td);
      const [X, Y] = sp(cam, ...BONES.toWorld(p.skull.cm));
      const vx = -Math.sin(th) * Math.sign(sl.thetaDot(td)), vy = Math.cos(th) * Math.sign(sl.thetaDot(td));
      arrow(ctx, X, Y, vx * v * 9, -vy * v * 9, { color: TOK.VEL, lw: 5 });
    }
    if (td >= cs.release && td < cs.release + 0.6) {
      const [X, Y] = sp(cam, XREL, H);
      arrow(ctx, X, Y, 0, (cs.phys.v0 > 0 ? -1 : 1) * 90, { color: TOK.VEL, lw: 6 });
      math(`v_{0} = ${vStr(cs.phys.v0)}`, X + 20, Y + (cs.phys.v0 > 0 ? -100 : 120), 32, TOK.VEL);
    }
  }

  // ------------------------------------------------------------------ split screen (falls)
  function strobe(cam, cs, tauNow) {
    for (const ts of strobeTimes(cs.phys)) {
      if (ts > tauNow + 1e-9) continue;
      const [X, Y] = sp(cam, XREL, yOf(cs.phys, ts));
      ctx.save(); ctx.globalAlpha = 0.9; ctx.fillStyle = G.light; ctx.strokeStyle = TOK.POS; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(X, Y, 15, 0, 2 * Math.PI); ctx.fill(); ctx.stroke(); ctx.restore();
      const left = cs.phys.v0 > 0 && ts < cs.phys.tApex - 1e-9;
      const lab = `t = ${fmt(ts, Math.abs(ts - Math.round(ts)) > 1e-9 ? 2 : 0)} s`;
      const lw2 = mathW(lab, 22);
      mathLine(ctx, lab, left ? X - 30 - lw2 : X + 30, Y + 8, 22, { font: SERIF, fill: G.paper, stroke: G.ink });
    }
  }
  function widePanel(td, cs, p, tau) {
    const cam = WIDE;
    ctx.save(); ctx.beginPath(); ctx.rect(0, 0, PANEL_X, Hh); ctx.clip();
    background(cam, td);
    drawGround(ink, cam, PANEL_X, Hh);
    drawBuilding(ink, cam, { t: td, detail: 0.4 });
    drawRuler(ink, cam, 1.7, { y0: 0, y1: 52 });
    skeletonInCam(cam, p, { filter: (d) => !isHead(d) });
    if (p.skull.cm) skullInCam(cam, p, 5);
    ctx.restore();
    laterClip(0, 0, PANEL_X, Hh, () => {
      strobe(cam, cs, tau);
      card(20, 20, 330, 44); text('OVERVIEW · true scale', 34, 50, 20, TOK.INK, { w: 700 });
      card(20, Hh - 60, 270, 40); text('(skull drawn ×5)', 34, Hh - 33, 18, TOK.MUTED, { it: true });
    });
    later(() => { ctx.fillStyle = TOK.BG; ctx.fillRect(PANEL_X - 3, 0, 6, Hh); });
  }
  function trackPanel(td, cs, p, tau) {
    const sk = p.skull;
    const wy = Math.max(1.75, BONES.toWorld(sk.cm)[1]);
    const cam = { wx: 0.95, wy, s: 250, cx: PANEL_X + 560, cy: 560 };
    const vel = sk.mode === 'free' ? vOf(cs.phys, tau) : 0;
    const blur = wy > 1.75 ? Math.abs(vel) * cam.s / 60 : 0; // 180° shutter at 30 fps
    ctx.save(); ctx.beginPath(); ctx.rect(PANEL_X + 3, 0, W - PANEL_X, Hh); ctx.clip();
    background(cam, td);
    drawGround(ink, cam, W, Hh);
    drawBuilding(ink, cam, { t: td, labels: true });
    drawRuler(ink, cam, 1.75, { y0: 0, y1: 55, blur });
    if (Math.abs(cam.wy - H) < 4) skeletonInCam(cam, p, { filter: (d) => !isHead(d) });
    const [X, Y] = skullInCam(cam, p, 1);
    if (sk.mode === 'free' && Math.abs(vel) > 0.05) { ctx.save(); ctx.globalAlpha = 0.7; ink.speedLines(X, Y, 0, vel < 0 ? 1 : -1, 3, Math.min(160, Math.abs(vel) * 6)); ctx.restore(); }
    ctx.restore();
    laterClip(PANEL_X + 3, 0, W - PANEL_X, Hh, () => {
      if (sk.mode === 'free') {
        arrow(ctx, X + 90, Y, 0, -vel * 8, { color: TOK.VEL, lw: 6 });
        math(`v = ${vStr(vel)}`, X + 112, Y - vel * 4 + 10, 30, TOK.VEL);
        arrow(ctx, X - 90, Y - 40, 0, GRAV * 8, { color: TOK.ACC, lw: 6 });
        math('a = -g', X - 220, Y + 20, 30, TOK.ACC);
      }
      card(PANEL_X + 30, 30, 470, 230);
      const yw = BONES.toWorld(sk.cm)[1];
      math(`t = ${fmt(tau, 2)} s`, PANEL_X + 56, 86, 40, TOK.INK);
      math(`y = ${fmt(Math.max(0, yw), 1)} m`, PANEL_X + 56, 142, 40, TOK.POS);
      math(`v = ${vStr(sk.mode === 'free' ? vel : sk.mode === 'ground' ? cs.phys.vImpact : 0)}`, PANEL_X + 56, 198, 40, TOK.VEL);
      math(`a = -${fmt(GRAV, 2)} m/s^{2}`, PANEL_X + 56, 244, 32, TOK.ACC);
      card(W - 470, 30, 440, 44); text('CAMERA FOLLOWING THE SKULL', W - 450, 60, 20, TOK.INK, { w: 700 });
      if (cs.sl && sk.mode === 'free') { card(W - 470, 84, 440, 44); math(`spinning: ω = ${fmt(BONES.OMEGA, 1)} rad/s (no torque)`, W - 450, 114, 20, TOK.MUTED); }
    });
  }
  function impactFx(td, cs) {
    const k = prog(td, cs.impact, cs.impact + 0.6);
    if (k <= 0 || k >= 1) return;
    const cam = { wx: 0.95, wy: 1.75, s: 250, cx: PANEL_X + 560, cy: 560 };
    const [X, Y] = sp(cam, XREL, 0);
    ctx.save(); ctx.beginPath(); ctx.rect(PANEL_X + 3, 0, W - PANEL_X, Hh); ctx.clip();
    for (let i = 0; i < 9; i++) {
      const a = Math.PI * (0.1 + 0.8 * (i / 8)), r = 40 + 170 * easeOut(k);
      ink.blob(X + r * Math.cos(a) * 1.3, Y - r * Math.sin(a) * 0.6, 26 * (1 - k) + 6, 18 * (1 - k) + 4, 0, { fill: 'rgba(150,150,150,0.8)', lw: 2.5 });
    }
    ink.takeLines(X, Y - 10, 110, 1 - k);
    ctx.restore();
  }
  function answer(td, cs) {
    const k = backOut(prog(td, cs.impact + 0.1, cs.impact + 0.45), 1.6);
    if (k <= 0) return;
    ctx.save(); ctx.translate(PANEL_X + 640, 420); ctx.scale(k, k);
    card(-330, -110, 660, 210, { border: TOK.GAL, lw: 5 });
    const l1 = `t = ${fmt(cs.phys.T, 2)} s`, l2 = `|v| = ${fmt(cs.phys.speedImpact, 1)} m/s \\down`;
    math(l1, -mathW(l1, 56) / 2, -24, 56, TOK.INK);
    math(l2, -mathW(l2, 56) / 2, 56, 56, TOK.VEL);
    ctx.restore();
  }

  // ------------------------------------------------------------------ white iris (clip bookends)
  function whiteIris(cx, cy, r) {
    octx.save();
    octx.setTransform(1, 0, 0, 1, 0, 0);
    octx.fillStyle = TOK.BG;
    octx.beginPath(); octx.rect(0, 0, W, Hh);
    if (r > 0) octx.arc(cx, cy, r, 0, 2 * Math.PI, true);
    octx.fill('evenodd');
    if (r > 0) { octx.strokeStyle = TOK.INK; octx.lineWidth = 3; octx.beginPath(); octx.arc(cx, cy, r, 0, 2 * Math.PI); octx.stroke(); }
    octx.restore();
  }
  const R_FULL = Math.hypot(W, Hh) * 0.62;
  function irisFor(t) {
    const clip = tl.clips.find((c) => t >= c.start - 1e-9 && t < c.end - 1e-9) || tl.clips[tl.clips.length - 1];
    // first and last frame of every clip are pure white (r = 0); the iris opens/closes in between
    const open = easeOut(prog(t, clip.start + 1 / FPS, clip.start + 0.9));
    const close = smooth(prog(t, clip.end - 1.0, clip.end - 1 / FPS));
    return { r: R_FULL * open * (1 - close), clip };
  }

  // ------------------------------------------------------------------ the frame
  async function renderAtTime(t, opts = {}) {
    const o = { film: true, ...opts };
    const f = Math.round(t * FPS);
    const td = C.drawT(t), di = C.drawIndex(t);
    ink.begin(di);
    celCtx.reset(); octx.reset(); post = []; ctx = celCtx;
    celCtx.fillStyle = '#000'; celCtx.fillRect(0, 0, W, Hh);
    let scene = '';
    let focus = [W / 2, Hh / 2];
    const cs = BONES.cases.find((c) => td >= c.start && td < c.end);
    if (td < S.intro[0]) {
      scene = 'establish';
      const u = easeInOut(prog(t, ...S.tilt));
      const cam = { wx: -4.5, wy: lerp(6, 34, u), s: lerp(30, 19, u), cx: W / 2, cy: 540 };
      background(cam, td);
      drawGround(ink, cam, W, Hh);
      drawBuilding(ink, cam, { t: td });
      drawRuler(ink, cam, 1.8, { y0: 0, y1: 50 });
      const p = { ...BONES.pose(td), drawIndex: di };
      skeletonInCam(cam, p);
      const lab = prog(td, 3.6, 4.4);
      if (lab > 0) later(() => {
        const [X1, Y1] = sp(cam, 4.2, H), [, Y0] = sp(cam, 4.2, 0);
        ctx.save(); ctx.globalAlpha = lab;
        arrow(ctx, X1, (Y0 + Y1) / 2, 0, ((Y1 - Y0) / 2) * 0.98, { color: TOK.POS }); arrow(ctx, X1, (Y0 + Y1) / 2, 0, ((Y0 - Y1) / 2) * 0.98, { color: TOK.POS });
        card(X1 + 20, (Y0 + Y1) / 2 - 40, 220, 64); math('h = 45 m', X1 + 36, (Y0 + Y1) / 2 + 8, 40, TOK.POS);
        ctx.restore();
      });
      later(() => chapter('B1', 'The Grand Skull Hotel', '15 floors of 3 m · 45 m tall · Halloween night'));
    } else if (td < S.cases[0].start) {
      scene = 'intro';
      const { p } = roofScene(td, di);
      later(() => chapter('B1', 'The falling object', 'Mr. Bones takes his head off: it will be the "particle"'));
      const u = prog(td, S.dataCard[0], S.dataCard[0] + 0.4);
      if (u > 0) later(() => {
        const x = 1320 + 600 * (1 - easeOut(u)), y = 200;
        card(x, y, 540, 470, { border: TOK.RULE });
        text('THE DATA', x + 28, y + 52, 30, TOK.INK, { w: 700 });
        const lines = [['h = 45 m', TOK.POS, 38], [`g = ${fmt(GRAV, 2)} m/s^{2}`, TOK.ACC, 38], ['+y axis points up,', TOK.INK, 30], ['origin at the ground', TOK.INK, 30], ['no air resistance', TOK.MUTED, 28], ['head = particle', TOK.MUTED, 28], ['(its centre of mass)', TOK.MUTED, 28]];
        lines.forEach(([l, col, px], i) => mathReveal(ctx, l, x + 30, y + 110 + i * 50, px, prog(td, S.dataCard[0] + 0.4 + i * 0.35, S.dataCard[0] + 0.75 + i * 0.35), { font: SERIF, fill: col, stroke: null }));
      });
      if (td >= S.popHead && td < S.popHead + 0.5) {
        const [X, Y] = sp(ROOF_CAM, ...BONES.toWorld(p.skull.cm));
        ink.takeLines(X, Y, 70, 1 - prog(td, S.popHead, S.popHead + 0.5));
        mathLine(ctx, 'POP!', X + 100, Y - 60, 64, { font: SERIF, fill: G.white, stroke: G.ink });
      }
      later(() => note('Animation: cartoon engine (171-bone rig) · exact physics from the shared constants file'));
    } else if (cs) {
      const titles = { 1: ['B2', 'Case 1 · released', 'v₀ = 0: the hand simply opens'], 2: ['B3', 'Case 2 · thrown downward', 'the sling: his left arm, spinning; released at v₀ = 10 m/s downward'], 3: ['B4', 'Case 3 · thrown upward', 'the sling spins the other way; released at v₀ = 10 m/s upward'] };
      const [nb, tt, sub] = titles[cs.id];
      if (td < cs.release || td >= cs.react[0]) {
        scene = td < cs.release ? `c${cs.id}-roof` : `c${cs.id}-react`;
        const { cam, p } = roofScene(td, di);
        later(() => slingOverlay(cam, p, cs, td));
        later(() => chapter(nb, tt, sub));
        if (td >= cs.react[0] + 1.0 - 0.1 && td < cs.react[1] + 0.2) {
          later(() => { card(60, 170, 520, 66); mathLine(ctx, '\\rew ×5   rewinding', 84, 218, 38, { font: SERIF, fill: TOK.INK, stroke: null }); });
        }
        if (td >= cs.react[0] && td < cs.react[0] + 0.8) mathLine(ctx, cs.id === 2 ? 'KA-BOOM!' : 'CRACK!', 1180, 300, 84, { font: SERIF, fill: G.white, stroke: G.ink });
        if (cs.sl && td >= cs.pull[1] && td < cs.pull[1] + 0.5) {
          const [X, Y] = sp(cam, ...BONES.toWorld(BONES.SH_L));
          ink.takeLines(X, Y, 60, 1 - prog(td, cs.pull[1], cs.pull[1] + 0.5));
          mathLine(ctx, 'CLACK!', X - 60, Y - 90, 60, { font: SERIF, fill: G.white, stroke: G.ink });
        }
        if (cs.sl && cs.reattach && td >= cs.reattach[1] - 0.1 && td < cs.reattach[1] + 0.4) mathLine(ctx, 'click!', 820, 380, 50, { font: SERIF, fill: G.white, stroke: G.ink });
        later(() => note(cs.sl ? 'Sling: fixed centre C, R = 0.575 m; spins 0.375 m in front of the facade; released with the radius horizontal (v vertical)' : 'Case 1: the hand opens with the skull at rest at 45 m (v₀ = 0)'));
      } else {
        scene = `c${cs.id}-fall`;
        const p = { ...BONES.pose(td), drawIndex: di };
        const tau = p.skull.mode === 'free' ? p.skull.tau : cs.phys.T;
        widePanel(td, cs, p, tau);
        trackPanel(td, cs, p, tau);
        impactFx(td, cs);
        later(() => answer(td, cs));
      }
    } else {
      scene = 'finale';
      const { cam, p } = roofScene(td, di);
      later(() => chapter('B5', 'And the head goes back on', 'same g in all three cases · t and v change, the acceleration does not'));
      const head = p.ev.fr.head ? p.ev.fr.head.t : [0, 300, 0];
      focus = sp(cam, ...BONES.toWorld([head[0], head[1] + 30, head[2]]));
    }
    let fx = null;
    if (o.film) fx = film.apply(octx, cel, f, t);
    else { octx.setTransform(1, 0, 0, 1, 0, 0); octx.drawImage(cel, 0, 0); }
    ctx = octx; octx.setTransform(1, 0, 0, 1, 0, 0);
    for (const fn of post) fn();
    ctx = celCtx; post = [];
    const ir = irisFor(t);
    if (ir.r < R_FULL - 1) whiteIris(focus[0], focus[1], ir.r);
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    return { t, frameIndex: f, drawing: di, scene, layers: [scene], clip: ir.clip.name, film: fx };
  }

  window.STUDIO = { ready: true, duration: tl.project.duration, fps: FPS, renderAtTime, info: { production: tl.project.slug } };
  void [CASES, drawBat, sy, smooth, GRAV];
}

boot().catch((e) => { window.STUDIO = { ready: false, error: String(e && e.stack ? e.stack : e) }; console.error(e); });
