// "Mr. Bones": a dapper rubber-hose skeleton in a top hat and bow tie (original design).
// Local units: feet on y = 0, up is negative y; ~360 units tall with the hat at scale 1.
import { G } from '../lib/ink.js';

export const SKELETON_REST = {
  x: 0, y: 0, s: 1, flip: 1, lean: 0, squash: 1, lift: 0, headTilt: 0, jaw: 0.15, look: [0.3, 0], blink: 0,
  hatLift: 0, hatTilt: 0, hatOn: true, take: 0, ribFlash: -1,
  armB: { hand: [-62, 70], bend: -0.25, pose: 'open' }, // back arm (hand relative to shoulder)
  armF: { hand: [62, 70], bend: 0.25, pose: 'open' }, // front arm
  legB: { foot: [-22, 0], bend: 0.12 }, // back leg (foot relative to ground origin)
  legF: { foot: [22, 0], bend: -0.12 },
  mallet: false, // holds a bone mallet in the front hand (xylophone gag)
};

export function drawSkeleton(ink, p0) {
  const p = { ...SKELETON_REST, ...p0 };
  const ctx = ink.ctx;
  ctx.save();
  ctx.translate(p.x, p.y);
  ctx.scale(p.s * p.flip, p.s);
  const HIP = [0, -112];
  // upper body transform: lean about the hips, squash about the feet, lift
  const U = (x, y) => {
    const c = Math.cos(p.lean), s = Math.sin(p.lean);
    const dx = x - HIP[0], dy = y - HIP[1];
    const rx = HIP[0] + dx * c - dy * s, ry = HIP[1] + dx * s + dy * c;
    return [rx / Math.sqrt(p.squash), ry * p.squash - p.lift];
  };
  const hip = [HIP[0], HIP[1] * p.squash - p.lift];
  const shB = U(-36, -218), shF = U(36, -218);
  const neck = U(0, -238);

  const arm = (sh, a, side) => {
    const hand = [sh[0] + a.hand[0], sh[1] + a.hand[1]];
    ink.hose(sh, hand, a.bend, 9, G.white);
    const ang = Math.atan2(a.hand[1], a.hand[0]);
    ink.glove(hand[0], hand[1], ang, 0.95, a.pose, 1);
    return hand;
  };
  const leg = (l, side) => {
    const h = [hip[0] + side * 14, hip[1] + 4];
    const f = [l.foot[0], l.foot[1] - 8];
    ink.hose(h, f, l.bend, 9, G.white);
    ink.shoe(f[0] - 6, f[1] + 8, 1.0, 1, 0);
  };

  // back limbs
  arm(shB, p.armB, -1);
  leg(p.legB, -1);
  // pelvis
  ink.shape([[hip[0] - 26, hip[1] - 8], [hip[0] - 8, hip[1] - 16], [hip[0], hip[1] - 6], [hip[0] + 8, hip[1] - 16],
    [hip[0] + 26, hip[1] - 8], [hip[0] + 18, hip[1] + 10], [hip[0], hip[1] + 4], [hip[0] - 18, hip[1] + 10]], { fill: G.white });
  leg(p.legF, 1);
  // spine
  const chest = U(0, -186);
  ink.hose([hip[0], hip[1] - 10], [chest[0], chest[1] + 40], 0, 8, G.white);
  // ribcage: black cavity, white ribs
  const rc = U(0, -188);
  ink.blob(rc[0], rc[1], 42 / Math.sqrt(p.squash), 50 * p.squash, p.lean, { fill: G.black });
  const ribs = 4;
  for (let k = 0; k < ribs; k++) {
    const yy = -214 + k * 15;
    const flash = p.ribFlash === k;
    for (const sd of [-1, 1]) {
      const a = U(0, yy), b = U(sd * 26, yy - 5), c = U(sd * 36 * (1 - k * 0.06), yy + 9);
      ink.trace([a, b, c], false, 0.5);
      ctx.lineCap = 'round';
      ctx.strokeStyle = G.ink; ctx.lineWidth = 12; ctx.stroke();
      ctx.strokeStyle = flash ? G.glow : G.white; ctx.lineWidth = 7; ctx.stroke();
    }
    if (flash) {
      // a struck rib rings: little vibration marks
      const m = U(46, yy + 2);
      for (let q = 0; q < 3; q++) ink.shape([[m[0] + q * 9, m[1] - 9 + q * 2], [m[0] + q * 9 + 6, m[1] + 9 - q * 2]], { closed: false, lw: 3 });
    }
  }
  ink.hose(U(0, -222), U(0, -150), 0, 6, G.white); // sternum
  // arm holding the mallet goes in front of the ribs
  // bow tie
  const bt = U(0, -236);
  ink.shape([[bt[0], bt[1]], [bt[0] - 18, bt[1] - 10], [bt[0] - 18, bt[1] + 10]], { fill: G.black });
  ink.shape([[bt[0], bt[1]], [bt[0] + 18, bt[1] - 10], [bt[0] + 18, bt[1] + 10]], { fill: G.black });
  ink.blob(bt[0], bt[1], 5, 5, 0, { fill: G.black });

  // skull (with its own tilt about the neck)
  ctx.save();
  ctx.translate(neck[0], neck[1]);
  ctx.rotate(p.headTilt + p.lean * 0.5);
  const take = p.take; // 0..1: eyes and skull stretch in surprise
  ctx.scale(1 - 0.08 * take, 1 + 0.18 * take);
  const SK = 1.0;
  // jaw (drawn first, behind the cranium)
  const jy = 12 + p.jaw * 16;
  ink.shape([[-26, -6], [26, -6], [24, jy], [12, jy + 8], [-12, jy + 8], [-24, jy]], { fill: G.white });
  for (let k = -2; k <= 2; k++) ink.shape([[k * 8, jy - 2], [k * 8, jy + 5]], { closed: false, lw: 2 });
  // mouth cavity when the jaw drops
  if (p.jaw > 0.25) ink.blob(0, 4 + p.jaw * 6, 18, 3 + p.jaw * 7, 0, { fill: G.black, lw: 0 });
  // cranium
  ink.shape([[-40, -42], [-30, -70], [0, -80], [30, -70], [40, -42], [36, -16], [26, -2], [-26, -2], [-36, -16]].map(([x, y]) => [x * SK, y * SK]), { fill: G.white });
  // upper teeth
  ink.shape([[-22, -4], [22, -4]], { closed: false, lw: 2.5 });
  for (let k = -2; k <= 2; k++) ink.shape([[k * 8, -10], [k * 8, -2]], { closed: false, lw: 2 });
  // nose hole
  ink.shape([[0, -26], [-6, -16], [6, -16]], { fill: G.black, lw: 2 });
  // eye sockets with pie-cut pupils
  const er = 1 + 0.5 * take;
  ink.pieEye(-16, -42, 13 * er, 16 * er, p.look, p.blink);
  ink.pieEye(16, -42, 13 * er, 16 * er, p.look, p.blink);
  // top hat
  if (p.hatOn) {
    ctx.save();
    ctx.translate(4, -76 - p.hatLift * 46);
    ctx.rotate(-0.12 + p.hatTilt);
    ink.shape([[-42, 2], [42, 2], [40, -8], [-40, -8]], { fill: G.black });
    ink.shape([[-26, -6], [-24, -62], [24, -62], [26, -6]], { fill: G.black });
    ink.shape([[-25, -14], [25, -14], [25, -24], [-25, -24]], { fill: G.mid, lw: 2 });
    ink.shape([[-14, -56], [-13, -32]], { closed: false, ink: G.mid, lw: 3 }); // sheen
    ctx.restore();
  }
  ctx.restore();
  if (take > 0.05) ink.takeLines(neck[0], neck[1] - 46, 70, take);

  // front arm (+ mallet)
  const hand = arm(shF, p.armF, 1);
  if (p.mallet) {
    const ang = Math.atan2(p.armF.hand[1], p.armF.hand[0]) + 0.9;
    const tip = [hand[0] + Math.cos(ang) * 70, hand[1] + Math.sin(ang) * 70];
    ink.hose(hand, tip, 0.02, 8, G.white);
    ink.blob(tip[0], tip[1], 11, 9, ang, { fill: G.white });
    ink.blob(hand[0] - Math.cos(ang) * 8, hand[1] - Math.sin(ang) * 8, 9, 7, ang, { fill: G.white });
  }
  ctx.restore();
  return { neck, hip };
}

// the top hat alone (when it parts company with its owner)
export function drawTopHat(ink, x, y, s = 1, rot = 0) {
  const ctx = ink.ctx;
  ctx.save();
  ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s);
  ink.shape([[-42, 2], [42, 2], [40, -8], [-40, -8]], { fill: G.black });
  ink.shape([[-26, -6], [-24, -62], [24, -62], [26, -6]], { fill: G.black });
  ink.shape([[-25, -14], [25, -14], [25, -24], [-25, -24]], { fill: G.mid, lw: 2 });
  ctx.restore();
}
