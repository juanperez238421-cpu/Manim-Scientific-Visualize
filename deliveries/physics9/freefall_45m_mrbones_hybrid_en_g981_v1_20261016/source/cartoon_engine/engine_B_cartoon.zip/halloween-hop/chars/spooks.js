// Sheet ghosts, bats and the man in the moon (original designs, period style).
import { G } from '../lib/ink.js';

// Ghost: origin at the hem centre. rise: 0 (in the ground) .. 1 (fully up)
export function drawGhost(ink, g) {
  const { x, y, s = 1, rise = 1, sing = 0, phase = 0, kick = 0, kickSide = 1, arms = 0, look = [0, 0], blink = 0, take = 0, lean = 0 } = g;
  if (rise <= 0) return;
  const ctx = ink.ctx;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(lean);
  ctx.scale(s * (1 - 0.12 * take), s * rise * (1 + 0.15 * take));
  // kicking leg pokes out from under the sheet (behind it)
  if (kick > 0.02) {
    const f = [kickSide * 40 * kick, -18 - 46 * kick];
    ink.hose([kickSide * 6, -24], f, -0.2 * kickSide, 9, G.black);
    ink.shoe(f[0], f[1] + 6, 0.9, kickSide, -kickSide * 0.6 * kick);
  }
  // sheet
  const pts = [];
  const H = 170, R = 52;
  for (let i = 0; i <= 10; i++) { // dome
    const a = Math.PI + (Math.PI * i) / 10;
    pts.push([R * Math.cos(a), -H + R + R * Math.sin(a)]);
  }
  pts.push([R + 6, -70], [R + 14, -14]);
  for (let k = 4; k >= 0; k--) { // scalloped hem, swaying
    const xx = -R - 14 + ((2 * R + 28) * k) / 4;
    const w = Math.sin(phase * 2 * Math.PI + k * 1.3) * 7;
    pts.push([xx + w, (k % 2 ? -6 : 6)]);
  }
  pts.push([-R - 14, -14], [-R - 6, -70]);
  ink.shape(pts, { fill: G.white });
  // arms: little sheet lumps
  for (const sd of [-1, 1]) {
    const ay = -82 - 30 * arms;
    ink.shape([[sd * (R - 2), ay + 26], [sd * (R + 22), ay - 4 - 14 * arms], [sd * (R + 30), ay + 6 - 14 * arms], [sd * (R + 4), ay + 40]], { fill: G.white, amp: 0.7 });
  }
  // face
  const er = 1 + 0.5 * take;
  ink.pieEye(-17, -H + 54, 10 * er, 15 * er, look, blink);
  ink.pieEye(17, -H + 54, 10 * er, 15 * er, look, blink);
  const mo = 0.15 + 0.85 * sing;
  ink.blob(0, -H + 92, 9 + 3 * mo, 4 + 13 * mo, 0, { fill: G.black, lw: 2.5 });
  ctx.restore();
}

// Bat: flap in [0,1) is the wing-beat phase
export function drawBat(ink, b) {
  const { x, y, s = 1, flap = 0, flip = 1 } = b;
  const ctx = ink.ctx;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s * flip, s);
  const up = Math.sin(flap * 2 * Math.PI);
  for (const sd of [-1, 1]) {
    const tip = [sd * 74, -34 * up];
    ink.shape([[sd * 10, -6], [sd * 30, -22 * up - 6], tip, [sd * 62, -34 * up + 18], [sd * 50, -20 * up + 8], [sd * 38, -14 * up + 18], [sd * 24, -8 * up + 8], [sd * 12, 8]], { fill: G.black, lw: 3 });
  }
  ink.blob(0, 0, 16, 20, 0, { fill: G.black, lw: 3 });
  ink.shape([[-12, -14], [-14, -32], [-4, -18]], { fill: G.black, lw: 3 });
  ink.shape([[12, -14], [14, -32], [4, -18]], { fill: G.black, lw: 3 });
  ink.blob(-6, -6, 4, 5, 0, { fill: G.white, ink: null, lw: 0 });
  ink.blob(6, -6, 4, 5, 0, { fill: G.white, ink: null, lw: 0 });
  ctx.restore();
}

// Moon: yawn 0..1, wink 0..1 (left eye), sing 0..1, sleepy 0..1 (lids), look
export function drawMoon(ink, m) {
  const { x, y, r = 120, yawn = 0, wink = 0, sing = 0, sleepy = 0, look = [0, 0], tilt = 0 } = m;
  const ctx = ink.ctx;
  // halo
  const g = ctx.createRadialGradient(x, y, r * 0.9, x, y, r * 2.4);
  g.addColorStop(0, 'rgba(255,255,255,0.22)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = g;
  ctx.fillRect(x - r * 2.5, y - r * 2.5, r * 5, r * 5);
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(tilt);
  ink.blob(0, 0, r, r, 0, { fill: G.paper });
  for (const [cx, cy, cr] of [[-0.45, -0.5, 0.16], [0.5, -0.35, 0.12], [0.55, 0.45, 0.1], [-0.6, 0.35, 0.09]]) {
    ink.blob(cx * r, cy * r, cr * r, cr * r * 0.8, 0, { fill: G.light, ink: G.stone, lw: 2 });
  }
  const ex = 0.33 * r, ey = -0.08 * r;
  // eyes: sleepy lids / open pie eyes / wink arc
  for (const sd of [-1, 1]) {
    const closed = sd === -1 ? Math.max(sleepy, wink) : sleepy;
    if (closed > 0.7) {
      ink.shape([[sd * ex - 20, ey], [sd * ex, ey + 10], [sd * ex + 20, ey]], { closed: false, lw: 4.5 });
    } else {
      ink.pieEye(sd * ex, ey, 13, 19, look, closed);
    }
  }
  // nose
  ink.shape([[0.02 * r, -0.02 * r], [0.12 * r, 0.18 * r], [0.0, 0.2 * r]], { closed: false, lw: 3.5 });
  // mouth: smile, yawn oval or singing "O"
  const open = Math.max(yawn, sing * 0.7);
  if (open > 0.08) {
    ink.blob(0, 0.42 * r, 0.18 * r + 0.06 * r * yawn, 0.06 * r + 0.22 * r * open, 0, { fill: G.black });
  } else {
    ink.shape([[-0.3 * r, 0.36 * r], [0, 0.5 * r], [0.3 * r, 0.36 * r]], { closed: false, lw: 4.5 });
  }
  ctx.restore();
}
