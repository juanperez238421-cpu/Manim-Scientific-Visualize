// "Jack": a jack-o'-lantern-headed hoofer on a black rubber-hose body (original design).
// Feet on y = 0; ~330 units tall at scale 1. Carved holes glow white and flicker.
import { G } from '../lib/ink.js';

export const PUMPKIN_REST = {
  x: 0, y: 0, s: 1, flip: 1, lean: 0, squash: 1, lift: 0, headTilt: 0, grin: 0.4, look: [0.3, 0], take: 0, glow: 1,
  armB: { hand: [-64, 64], bend: -0.25, pose: 'open' },
  armF: { hand: [64, 64], bend: 0.25, pose: 'open' },
  legB: { foot: [-24, 0], bend: 0.12 },
  legF: { foot: [24, 0], bend: -0.12 },
};

export function drawPumpkin(ink, p0) {
  const p = { ...PUMPKIN_REST, ...p0 };
  const ctx = ink.ctx;
  ctx.save();
  ctx.translate(p.x, p.y);
  ctx.scale(p.s * p.flip, p.s);
  const HIP = [0, -96];
  const U = (x, y) => {
    const c = Math.cos(p.lean), s = Math.sin(p.lean);
    const dx = x - HIP[0], dy = y - HIP[1];
    return [(HIP[0] + dx * c - dy * s) / Math.sqrt(p.squash), (HIP[1] + dx * s + dy * c) * p.squash - p.lift];
  };
  const hip = [HIP[0], HIP[1] * p.squash - p.lift];
  const shB = U(-34, -170), shF = U(34, -170);
  const arm = (sh, a) => {
    const hand = [sh[0] + a.hand[0], sh[1] + a.hand[1]];
    ink.hose(sh, hand, a.bend, 10, G.black);
    ink.glove(hand[0], hand[1], Math.atan2(a.hand[1], a.hand[0]), 0.95, a.pose, 1);
  };
  const leg = (l, side) => {
    const h = [hip[0] + side * 16, hip[1]];
    const f = [l.foot[0], l.foot[1] - 8];
    ink.hose(h, f, l.bend, 10, G.black);
    ink.shoe(f[0] - 6, f[1] + 8, 1.05, 1, 0);
  };
  arm(shB, p.armB);
  leg(p.legB, -1);
  leg(p.legF, 1);
  // body: a round black torso with three white buttons
  const b = U(0, -134);
  ink.blob(b[0], b[1], 44 / Math.sqrt(p.squash), 50 * p.squash, p.lean, { fill: G.black });
  for (let k = 0; k < 3; k++) { const q = U(0, -156 + k * 20); ink.blob(q[0], q[1], 5, 5, 0, { fill: G.white, lw: 2 }); }
  // white collar ruffle
  const n = U(0, -182);
  for (let k = -2; k <= 2; k++) ink.blob(n[0] + k * 13, n[1] + 2 - Math.abs(k) * 2, 10, 7, 0, { fill: G.white, lw: 2.4 });

  // head
  const hc = U(0, -238);
  drawPumpkinHead(ink, { x: hc[0], y: hc[1], rot: p.headTilt + p.lean * 0.5, take: p.take, grin: p.grin, look: p.look, glow: p.glow });
  if (p.take > 0.05) ink.takeLines(hc[0], hc[1], 92, p.take);
  arm(shF, p.armF);
  ctx.restore();
}

// the jack-o'-lantern head alone (also used on the title and end cards)
export function drawPumpkinHead(ink, { x, y, s = 1, rot = 0, take = 0, grin = 0.4, look = [0, 0], glow: gl = 1 }) {
  const ctx = ink.ctx;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.scale(s * (1 - 0.06 * take), s * (1 + 0.15 * take));
  ink.shape([[-6, -54], [-4, -76], [8, -84], [12, -78], [5, -70], [7, -54]], { fill: G.shadow });
  ink.blob(0, 0, 72, 58, 0, { fill: G.stone });
  // ribs: full arcs on the flanks, short creases top and bottom so the face stays clean
  for (const k of [-0.86, 0.86]) {
    ink.trace([[k * 50, -52], [k * 80, 0], [k * 50, 52]], false, 0.6);
    ctx.strokeStyle = G.mid; ctx.lineWidth = 3; ctx.stroke();
  }
  for (const k of [-0.3, 0.3]) {
    for (const sy of [-1, 1]) {
      ink.trace([[k * 40, sy * 57], [k * 52, sy * 44]], false, 0.4);
      ctx.strokeStyle = G.mid; ctx.lineWidth = 3; ctx.stroke();
    }
  }
  const glow = gl > 0.5 ? G.glow : G.paper;
  const er = 1 + 0.6 * take;
  for (const sd of [-1, 1]) {
    ink.shape([[sd * 14, -10], [sd * (14 + 30 * er), -10], [sd * 26, -38 * er]], { fill: glow });
    ink.blob(sd * 25 + look[0] * 4, -18 + look[1] * 3, 4.5 * er, 4.5 * er, 0, { fill: G.black, lw: 0 });
  }
  ink.shape([[0, -6], [-7, 6], [7, 6]], { fill: glow, lw: 3 });
  const gh = 10 + 16 * grin;
  ink.shape([[-44, 14], [-30, 18], [-24, 12], [-16, 20], [-6, 14], [6, 20], [16, 14], [24, 20], [32, 14], [44, 14],
    [30, 14 + gh], [10, 18 + gh], [-10, 18 + gh], [-30, 14 + gh]], { fill: glow, amp: 0.5 });
  ctx.restore();
}
