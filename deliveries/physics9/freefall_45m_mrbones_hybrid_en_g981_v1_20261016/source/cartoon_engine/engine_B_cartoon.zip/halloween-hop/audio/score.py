"""Original score and sound effects for "Hallowe'en Hop" — a 1930s-style hot-jazz number in
D minor at 180 BPM, synthesised from code (no samples), then run through an "optical
soundtrack" chain (mono, band-limited, wow, crackle). All times come from ../timeline.json:
t = beat * 60 / bpm, so every hit lands on the same frame as its picture event.

usage: .venv/bin/python productions/halloween-hop/audio/score.py
writes build/halloween-hop/audio/{mix.wav, cue_sheet.json, stems/*.npy}
"""
import json
import math
import sys
from pathlib import Path

import numpy as np
from scipy.signal import butter, lfilter, sosfilt

HERE = Path(__file__).resolve().parent
PROD = HERE.parent
ROOT = PROD.parents[1]
sys.path.insert(0, str(ROOT / "src" / "audio"))
from synth import limiter, measure, write_wav  # noqa: E402  (shared loudness tools)

SR = 48000
TL = json.loads((PROD / "timeline.json").read_text())
BPM = TL["music"]["bpm"]
SPB = 60.0 / BPM
E = TL["events"]
DUR = TL["project"]["duration"]
RNG = np.random.default_rng(TL["project"]["seed"])
N = int(round(DUR * SR))
# skeleton cues derived from the rig's physics (tools/export_cues.mjs): where bodies really land
RIG_CUES = json.loads((ROOT / "build" / PROD.name / "rig_cues.json").read_text())


def bt(b):
    return b * SPB


def hz(m):
    return 440.0 * 2 ** ((m - 69) / 12)


NOTE = {"C": 0, "C#": 1, "Db": 1, "D": 2, "D#": 3, "Eb": 3, "E": 4, "F": 5, "F#": 6, "Gb": 6, "G": 7, "G#": 8, "Ab": 8, "A": 9, "A#": 10, "Bb": 10, "B": 11}


def m(name):
    """'A4' -> midi"""
    n, o = name[:-1], int(name[-1])
    return 12 * (o + 1) + NOTE[n]


def env_adsr(n, a, d, s, r, sr=SR):
    a, d, r = int(a * sr), int(d * sr), int(r * sr)
    e = np.full(n, s, float)
    a = min(a, n)
    e[:a] = np.linspace(0, 1, a, endpoint=False) if a else e[:a]
    dd = min(d, max(0, n - a))
    e[a:a + dd] = np.linspace(1, s, dd, endpoint=False) if dd else e[a:a + dd]
    r = min(r, n)
    if r:
        e[n - r:] *= np.linspace(1, 0, r)
    return e


def tvec(n):
    return np.arange(n) / SR


# ------------------------------------------------------------------ instruments
def tuba(f, dur, vel=1.0):
    n = int(dur * SR)
    t = tvec(n)
    vib = 1 + 0.003 * np.sin(2 * np.pi * 4.5 * t)
    ph = 2 * np.pi * np.cumsum(f * vib) / SR
    x = np.sin(ph) + 0.45 * np.sin(2 * ph) + 0.2 * np.sin(3 * ph) + 0.08 * np.sin(4 * ph)
    return 0.5 * vel * x * env_adsr(n, 0.018, 0.12, 0.55, 0.05)


def ks_pluck(f, dur, bright=0.5):
    """Karplus-Strong plucked string (banjo-like: bright, fast decay)"""
    n = int(dur * SR)
    P = max(2, int(round(SR / f)))
    exc = RNG.uniform(-1, 1, P)
    exc = lfilter([bright, 1 - bright], [1], exc)
    x = np.zeros(n)
    x[:P] = exc
    a = np.zeros(P + 2)
    a[0] = 1
    a[P] = -0.5 * 0.985
    a[P + 1] = -0.5 * 0.985
    y = lfilter([1], a, x)
    return y * env_adsr(n, 0.001, 0.0, 1.0, 0.03)


def banjo_strum(midis, dur, vel=1.0):
    n = int(dur * SR)
    out = np.zeros(n)
    for i, mm in enumerate(midis):
        d = int(0.011 * i * SR)
        s = ks_pluck(hz(mm), dur - d / SR, 0.55)
        out[d:d + len(s)] += s
    return 0.35 * vel * out


def additive(f, n, partials, vib_rate=5.5, vib_depth=0.0, t0=0.0):
    t = tvec(n)
    vib = 1 + vib_depth * np.sin(2 * np.pi * vib_rate * t + t0) * np.clip(t / 0.15, 0, 1)
    ph = 2 * np.pi * np.cumsum(f * vib) / SR
    return sum(a * np.sin(k * ph) for k, a in partials)


def onepole(x, fc):
    fc = np.broadcast_to(np.asarray(fc, float), x.shape)
    a = np.exp(-2 * np.pi * fc / SR)
    y = np.empty_like(x)
    s = 0.0
    for i in range(len(x)):
        s = (1 - a[i]) * x[i] + a[i] * s
        y[i] = s
    return y


def trumpet(f, dur, vel=1.0, wah=True):
    """muted trumpet: bright additive brass through a plunger 'wah' (time-varying low-pass)"""
    n = int(dur * SR)
    parts = [(k, 1.0 / k ** 0.8) for k in range(1, 13) if f * k < 9000]
    x = additive(f, n, parts, 5.2, 0.006)
    t = tvec(n)
    if wah:
        opening = np.clip(t / max(0.06, dur * 0.45), 0, 1)
        fc = 500 + 2600 * np.sin(np.pi * 0.5 * opening) * np.exp(-0.6 * t)
    else:
        fc = np.full(n, 3000.0)
    y = onepole(onepole(x, fc), fc)
    return 0.28 * vel * y * env_adsr(n, 0.025, 0.08, 0.8, 0.05)


def clarinet(f, dur, vel=1.0):
    n = int(dur * SR)
    x = additive(f, n, [(1, 1.0), (3, 0.45), (5, 0.25), (7, 0.12), (9, 0.06)], 5.0, 0.004)
    return 0.22 * vel * onepole(x, 2500) * env_adsr(n, 0.04, 0.1, 0.85, 0.06)


_vowel_oo = [(300, 60, 1.0), (870, 90, 0.35), (2240, 120, 0.12)]


def choir(f, dur, vel=1.0):
    """ghost 'oooo' — sawtooth glottal source through three formant resonators"""
    n = int(dur * SR)
    t = tvec(n)
    vib = 1 + 0.012 * np.sin(2 * np.pi * 5.0 * t + RNG.uniform(0, 6)) * np.clip(t / 0.2, 0, 1)
    ph = np.cumsum(f * vib) / SR
    src = 2 * (ph % 1) - 1
    out = np.zeros(n)
    for fc, bw, g in _vowel_oo:
        r = math.exp(-math.pi * bw / SR)
        th = 2 * math.pi * fc / SR
        out += g * lfilter([1 - r], [1, -2 * r * math.cos(th), r * r], src)
    out = out / (np.abs(out).max() + 1e-12)  # resonators have large gain: normalise the voice
    return 0.16 * vel * out * env_adsr(n, 0.09, 0.15, 0.85, 0.12)


def xylophone(f, vel=1.0):
    n = int(0.6 * SR)
    t = tvec(n)
    x = (np.sin(2 * np.pi * f * t) * np.exp(-t / 0.22) + 0.5 * np.sin(2 * np.pi * 3.98 * f * t) * np.exp(-t / 0.06)
         + 0.25 * np.sin(2 * np.pi * 9.1 * f * t) * np.exp(-t / 0.02))
    click = RNG.uniform(-1, 1, n) * np.exp(-t / 0.002) * 0.4
    return 0.45 * vel * (x + click)


def celesta(f, vel=1.0):
    n = int(1.2 * SR)
    t = tvec(n)
    return 0.22 * vel * (np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * 4 * f * t) * np.exp(-t / 0.1)) * np.exp(-t / 0.5)


def bell(f0=98.0, vel=1.0):
    """church bell: hum, prime, minor-third tierce, quint, nominal, upper partials"""
    n = int(3.0 * SR)
    t = tvec(n)
    parts = [(0.5, 0.8, 2.6), (1.0, 1.0, 1.6), (1.2, 0.7, 1.2), (1.5, 0.45, 1.0), (2.0, 0.55, 0.8), (2.51, 0.3, 0.5), (3.0, 0.25, 0.35), (4.07, 0.15, 0.2)]
    x = sum(a * np.sin(2 * np.pi * f0 * k * t) * np.exp(-t / d) for k, a, d in parts)
    strike = RNG.uniform(-1, 1, n) * np.exp(-t / 0.004)
    return 0.42 * vel * (x + 0.6 * strike)


def organ(chord, dur, vel=1.0):
    n = int(dur * SR)
    t = tvec(n)
    trem = 1 + 0.25 * np.sin(2 * np.pi * 6.0 * t)
    x = sum(np.sin(2 * np.pi * hz(mm) * t) + 0.3 * np.sin(4 * np.pi * hz(mm) * t) for mm in chord)
    return 0.07 * vel * x * trem * env_adsr(n, 0.6, 0.0, 1.0, 0.4)


def noise(n):
    return RNG.uniform(-1, 1, n)


def kick(vel=1.0):
    n = int(0.2 * SR)
    t = tvec(n)
    f = 40 + 40 * np.exp(-t / 0.03)
    return 0.6 * vel * np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.09)


def brush(vel=1.0):
    n = int(0.16 * SR)
    t = tvec(n)
    b, a = butter(2, [1500 / (SR / 2), 7000 / (SR / 2)], "band")
    return 0.28 * vel * lfilter(b, a, noise(n)) * np.exp(-t / 0.05)


def cymbal(vel=1.0, dur=1.6):
    n = int(dur * SR)
    t = tvec(n)
    b, a = butter(2, 4000 / (SR / 2), "high")
    return 0.32 * vel * lfilter(b, a, noise(n)) * np.exp(-t / (dur / 3.5))


def woodblock(f=900, vel=1.0):
    n = int(0.08 * SR)
    t = tvec(n)
    return 0.35 * vel * (np.sin(2 * np.pi * f * t) + 0.4 * np.sin(2 * np.pi * 2.3 * f * t)) * np.exp(-t / 0.018)


def roll(dur, vel=1.0):
    n = int(dur * SR)
    t = tvec(n)
    am = 0.5 + 0.5 * np.sin(2 * np.pi * 22 * t)
    b, a = butter(2, [1200 / (SR / 2), 6000 / (SR / 2)], "band")
    return 0.25 * vel * lfilter(b, a, noise(n)) * am * np.linspace(0.2, 1, n)


def slide_whistle(f0, f1, dur, vel=1.0):
    n = int(dur * SR)
    t = tvec(n)
    f = f0 * (f1 / f0) ** (t / dur) * (1 + 0.01 * np.sin(2 * np.pi * 7 * t))
    return 0.3 * vel * np.sin(2 * np.pi * np.cumsum(f) / SR) * env_adsr(n, 0.02, 0, 1, 0.04)


def whoosh(dur, up=True, vel=1.0):
    n = int(dur * SR)
    t = tvec(n)
    fc = np.where(up, 300 + 4000 * (t / dur), 4300 - 4000 * (t / dur))
    x = noise(n)
    y = onepole(x, fc) - onepole(x, fc * 0.3)
    return 0.6 * vel * y * np.sin(np.pi * t / dur)


def boing(f=180, dur=0.5, vel=1.0):
    n = int(dur * SR)
    t = tvec(n)
    f_t = f * (1 + 0.9 * np.exp(-t / 0.05)) * (1 + 0.06 * np.sin(2 * np.pi * 16 * t) * np.exp(-t / 0.2))
    return 0.35 * vel * np.sin(2 * np.pi * np.cumsum(f_t) / SR) * np.exp(-t / 0.18)


def thud(vel=1.0):
    n = int(0.3 * SR)
    t = tvec(n)
    return 0.6 * vel * (np.sin(2 * np.pi * np.cumsum(60 + 50 * np.exp(-t / 0.02)) / SR) * np.exp(-t / 0.08) + 0.3 * onepole(noise(n), 400) * np.exp(-t / 0.03))


def triangle(vel=1.0):
    n = int(1.5 * SR)
    t = tvec(n)
    return 0.12 * vel * sum(np.sin(2 * np.pi * f * t) * np.exp(-t / d) for f, d in ((2900, 0.6), (5200, 0.4), (7400, 0.25)))


# ------------------------------------------------------------------ arrangement
class Track:
    def __init__(self):
        self.x = np.zeros(N + SR * 4)
        self.cues = []
        self.stems = {}

    def add(self, b, sig, gain=1.0, cue=None):
        i = int(round(bt(b) * SR))
        self.x[i:i + len(sig)] += gain * sig
        if cue:
            self.cues.append({"id": cue, "beat": b, "t": round(bt(b), 6), "sample": i, "frame": round(bt(b) * TL["project"]["fps"], 3)})
            self.stems[cue] = (i, gain * sig)


CH = {  # chord tones for tuba (root, fifth) and banjo voicing
    "Dm": ([m("D2"), m("A1")], [m("D4"), m("F4"), m("A4"), m("D5")]),
    "Gm": ([m("G1"), m("D2")], [m("D4"), m("G4"), m("Bb4"), m("D5")]),
    "A7": ([m("A1"), m("E2")], [m("C#4"), m("E4"), m("G4"), m("A4")]),
    "D": ([m("D2"), m("A1")], [m("D4"), m("F#4"), m("A4"), m("D5")]),
}
SW = TL["music"]["swing"]


def rhythm(T, bar_chords, start_bar_beat, vel=1.0, drums=True, wood=False):
    for k, ch in enumerate(bar_chords):
        b0 = start_bar_beat + 4 * k
        roots, voicing = CH[ch]
        T.add(b0, tuba(hz(roots[0]), bt(0.9), vel), 1.0)
        T.add(b0 + 2, tuba(hz(roots[1]), bt(0.9), vel * 0.9), 1.0)
        for off in (1, 3):
            T.add(b0 + off, banjo_strum(voicing, bt(0.8), vel), 1.0)
        if drums:
            for off in (0, 2):
                T.add(b0 + off, kick(vel * 0.7))
            for off in (1, 3):
                T.add(b0 + off, brush(vel))
        if wood:
            for off in (1, 3):
                T.add(b0 + off + SW, woodblock(1100, vel * 0.6))


# melody: (beat offset, length in beats, note)
THEME = [
    (1, 0.67, "A4"), (1.67, 0.33, "D5"), (2, 1, "F5"), (3, 0.67, "E5"), (3.67, 0.33, "D5"),
    (4, 1, "C#5"), (5, 0.67, "D5"), (5.67, 0.33, "E5"), (6, 1.5, "F5"), (7.67, 0.33, "A4"),
    (8, 0.67, "Bb4"), (8.67, 0.33, "D5"), (9, 1, "G5"), (10, 0.67, "F5"), (10.67, 0.33, "E5"), (11, 1, "D5"),
    (12, 0.67, "F5"), (12.67, 0.33, "E5"), (13, 0.67, "D5"), (13.67, 0.33, "C#5"), (14, 1.5, "D5"), (15.67, 0.33, "A4"),
    (16, 0.67, "Bb4"), (16.67, 0.33, "C#5"), (17, 0.67, "E5"), (17.67, 0.33, "G5"), (18, 1, "Bb5"), (19, 1, "A5"),
    (20, 0.67, "F5"), (20.67, 0.33, "D5"), (21, 1, "A4"), (22, 2, "D5"),
]
RIB_PITCH = {0: "A5", 1: "F5", 2: "D5", 3: "A4"}


def arrange():
    T = Track()
    # --- intro, bars 1-4 (title card): vamp + spooky chromatic clarinet
    rhythm(T, ["Dm", "Dm", "A7", "A7"], 0, vel=0.7, drums=True)
    T.add(0, cymbal(0.6, 1.2))
    for k, (b, d, nt) in enumerate([(0, 1.5, "D5"), (1.67, 0.33, "C#5"), (2, 1.5, "C5"), (3.67, 0.33, "B4"), (4, 2, "Bb4"), (6, 2, "A4"),
                                    (8, 1, "G4"), (9, 1, "Bb4"), (10, 1, "C#5"), (11, 1, "E5"), (12, 2, "G5"), (14, 1.5, "A5")]):
        T.add(b, clarinet(hz(m(nt)), bt(d)), 1.0)
    # --- graveyard, bars 5-8: drone, bongs, celesta, drum roll into the pop
    T.add(16, organ([m("D3"), m("A3"), m("E4"), m("F4")], bt(16)), 1.0)
    for b, nt in ((16, "D2"), (20, "Bb1"), (24, "G1"), (28, "A1")):
        T.add(b, tuba(hz(m(nt)), bt(3.6), 0.7))
    for b in E["bongs"]:
        T.add(b, bell(98.0), 1.0, cue=f"bong@{b}")
    for k, nt in enumerate(["D6", "A5", "F5", "D5", "F5", "A5", "C#6", "E6"]):
        T.add(17.5 + k * 0.5 + (2 if k > 3 else 0), celesta(hz(m(nt))), 0.9)
    T.add(E["moundShake"][0], roll(bt(E["skeletonPop"] - E["moundShake"][0])), 1.0)
    T.add(E["handsUp"], slide_whistle(300, 900, bt(1.4)), 0.9)
    pop = E["skeletonPop"]
    T.add(pop, cymbal(1.0, 1.8), 1.0, cue="pop-crash")
    T.add(pop, boing(160, 0.6), 1.0)
    T.add(RIG_CUES["popLand"], thud(0.55), 0.8, cue="pop-land")  # feet hit the ground (ballistic landing)
    T.add(RIG_CUES["popLand"], woodblock(700, 0.6), 0.6)
    # --- main tune, bars 9-14 (dance + ghost chorus)
    rhythm(T, ["Dm", "Dm", "Gm", "Dm", "Gm", "Dm"], 32, vel=1.0, wood=True)
    for b, d, nt in THEME:
        T.add(32 + b, trumpet(hz(m(nt)), bt(d * 0.95)), 1.0)
    for b, d, nt in [(4, 2, "A4"), (6, 2, "G#4"), (8, 2, "G4"), (10, 2, "F#4"), (12, 4, "F4"), (16, 4, "E4"), (20, 4, "F4")]:
        T.add(32 + b, clarinet(hz(m(nt)), bt(d)), 0.7)
    ch_voice = {"Dm": ["D4", "F4", "A4"], "Gm": ["D4", "G4", "Bb4"]}
    for k, chn in enumerate(["Dm", "Gm", "Dm"]):
        for beat in range(4):
            b = E["ghostChorus"][0] + 4 * k + beat
            for v in ch_voice[chn]:
                T.add(b, choir(hz(m(v)), bt(0.92)), 0.45)
    # --- rib xylophone break, bars 15-16: tuba + banjo only, the skeleton plays
    rhythm(T, ["A7", "Dm"], 56, vel=0.75, drums=False)
    h = E["xyloHits"]
    for k, rib in enumerate(h["ribs"]):
        b = h["from"] + k * h["every"]
        T.add(b, xylophone(hz(m(RIB_PITCH[rib]))), 1.0, cue=f"xylo@{b}" if k in (0, 6, 13) else None)
    # --- finale, bars 17-19: full band
    rhythm(T, ["Dm", "Dm", "Gm"], 64, vel=1.15, wood=True)
    T.add(64, cymbal(1.0, 1.5), 1.0)
    for b, d, nt in THEME[:16]:
        if b < 12:
            T.add(64 + b, trumpet(hz(m(nt)), bt(d * 0.95), 1.1), 1.0)
            T.add(64 + b, clarinet(hz(m(nt) - 3 if nt not in ("D5", "A4") else m(nt) - 5), bt(d * 0.95)), 0.8)
            T.add(64 + b, xylophone(hz(m(nt) + 12)), 0.25)
    for k in range(3):
        for beat in range(4):
            for v in (["D4", "F4", "A4"] if k < 2 else ["D4", "G4", "Bb4"]):
                T.add(64 + 4 * k + beat, choir(hz(m(v)), bt(0.92)), 0.5)
    for b in range(64, 76):
        if b % 2 == 1:
            T.add(b, cymbal(0.35, 0.4))
    # --- skeleton stunts inside the finale: head toss (pop + catch), hop landing
    T.add(RIG_CUES["tossLaunch"], slide_whistle(500, 1300, bt(0.7)), 0.55, cue="head-toss")
    T.add(RIG_CUES["tossCatch"], woodblock(1100, 1.0), 0.8, cue="head-catch")
    T.add(RIG_CUES["hopLand"], brush(1.0))
    # --- the clock strikes one: band stops dead, take, scram
    T.add(E["bongTake"], bell(98.0, 1.2), 1.0, cue="bong-take")
    T.add(E["bongTake"] + 0.25, boing(240, 0.5), 0.9)
    T.add(E["scram"]["ghosts"], slide_whistle(1200, 300, bt(0.6)), 0.9)
    T.add(E["scram"]["pumpkin"], whoosh(bt(0.7), up=True), 0.8)
    # bones fly apart on the take, then clatter back together (a dry run of bone-on-bone clicks)
    ex = RIG_CUES["explode"]
    for k in range(9):
        T.add(ex[0] + 0.03 * k, woodblock(float(RNG.uniform(900, 2600)), 0.5), 0.35)
    for k in range(12):
        T.add(ex[3] - 0.36 + 0.03 * k + 0.012 * float(RNG.uniform()), woodblock(float(RNG.uniform(1100, 2900)), 0.55), 0.4)
    T.add(ex[3], woodblock(1500, 1.0), 0.8, cue="bones-clatter-together")
    # the dive: up to the apex, down into the grave; thud and hat plop where the simulation lands them
    T.add(RIG_CUES["scramLaunch"], slide_whistle(400, 1100, RIG_CUES["apex"] * SPB - RIG_CUES["scramLaunch"] * SPB), 0.8)
    T.add(RIG_CUES["apex"], slide_whistle(1100, 200, bt(RIG_CUES["graveThud"] - RIG_CUES["apex"])), 0.9)
    T.add(RIG_CUES["graveThud"], thud(), 0.9, cue="skeleton-lands-in-grave")
    T.add(RIG_CUES["hatPlop"], woodblock(420, 1.2), 1.0, cue="hat-plops-in")
    T.add(80, organ([m("D3"), m("A3"), m("F4")], bt(2.4), 0.6), 1.0)
    for k, nt in enumerate(["A5", "F5", "D5"]):
        T.add(80 + 0.5 * k, celesta(hz(m(nt))), 0.8)
    T.add(E["moonWink"] + 0.5, woodblock(1600, 0.7), 1.0, cue="moon-wink")  # wink closes mid-way
    T.add(E["moonWink"] + 0.5, triangle(), 1.0)
    # --- tag: "shave and a haircut ... two bits", band tutti, ending on D major
    tag = E["tag"]
    tag_notes = ["D5", "A4", "A4", "B4", "A4", "C#5", "D5"]
    for b, nt in zip(tag, tag_notes):
        d = 0.33 if b in (83, 83.5) else 0.6
        T.add(b, trumpet(hz(m(nt)), bt(d), 1.2, wah=False), 1.0)
        T.add(b, clarinet(hz(m(nt) - 12), bt(d)), 0.9)
        T.add(b, xylophone(hz(m(nt))), 0.5)
        T.add(b, woodblock(1300, 1.0), 0.8, cue=f"tag@{b}" if b in (tag[5], tag[6]) else None)  # transient that marks the hit
        T.add(b, brush(1.3))
    for b, root in ((82, "D2"), (84, "A1"), (87, "A1"), (88, "D2")):
        T.add(b, tuba(hz(m(root)), bt(0.9), 1.1))
    T.add(tag[-1], cymbal(0.9, 2.0), 1.0)
    for v in ("D4", "F#4", "A4", "B4", "D5"):
        T.add(tag[-1] + 0.02, trumpet(hz(m(v)), bt(1.9), 0.6, wah=False), 0.8)
    return T


# ------------------------------------------------------------------ optical-track character
def period_chain(x, crackle=True):
    """mono, band-limited (optical track), gentle saturation, wow; optional surface crackle + hiss"""
    sos = butter(2, [110 / (SR / 2), 5200 / (SR / 2)], "band", output="sos")
    y = sosfilt(sos, x)
    y = np.tanh(1.6 * y) / 1.6
    t = np.arange(len(y)) / SR
    d = 0.0004 * np.sin(2 * np.pi * 0.55 * t) + 0.00015 * np.sin(2 * np.pi * 3.1 * t)  # seconds of wow/flutter
    y = np.interp(t - d, t, y)
    if crackle:
        rng = np.random.default_rng(TL["project"]["seed"] + 1)
        clicks = np.zeros(len(y))
        idx = rng.choice(len(y), size=int(7 * len(y) / SR), replace=False)
        clicks[idx] = rng.uniform(-1, 1, len(idx)) * rng.uniform(0.05, 0.35, len(idx))
        clicks = lfilter([1, -0.6], [1], clicks)
        hiss = sosfilt(butter(1, [800 / (SR / 2), 6000 / (SR / 2)], "band", output="sos"), rng.normal(0, 0.006, len(y)))
        y = y + 0.06 * clicks + hiss
    return y


def main():
    out = ROOT / "build" / PROD.name / "audio"
    (out / "stems").mkdir(parents=True, exist_ok=True)
    T = arrange()
    x = T.x[:N]
    fo = np.clip((DUR - np.arange(N) / SR) / 0.6, 0, 1)  # last 0.6 s fade
    raw_peak = float(np.abs(x).max())
    x = x * (0.5 / raw_peak)  # drive the optical-track saturation gently (tanh(0.8) at the loudest peak)
    y = period_chain(x) * fo
    L = TL["render"]["loudness"]
    g = 0.5 / np.abs(y).max()
    hist = []
    for it in range(6):
        z, gr = limiter(np.stack([y * g, y * g], axis=1), L["maxTruePeakDBTP"] - 0.5)
        write_wav(out / "mix.wav", z)
        mm = measure(out / "mix.wav")
        hist.append({"iter": it, "gain": g, "limiter_min_gain_db": 20 * math.log10(gr), **mm})
        err = L["targetLUFS"] - mm["integrated_lufs"]
        if abs(err) <= 0.2:
            break
        g *= 10 ** (err / 20)
    # stems for sync tests: each cue alone through the same linear filtering (no crackle), first 0.25 s
    for cid, (i0, sig) in T.stems.items():
        s = np.zeros(int(0.25 * SR))
        s[: min(len(s), len(sig))] = sig[: len(s)]
        np.save(out / "stems" / f"{cid.replace('@', '_')}.npy", period_chain(s, crackle=False))
    cue_sheet = {"raw_peak_before_chain": raw_peak, "bpm": BPM, "seconds_per_beat": SPB, "sample_rate": SR, "channels": "mono (duplicated L/R)",
                 "cues": T.cues, "normalisation": hist, "measured": hist[-1], "target": L}
    (out / "cue_sheet.json").write_text(json.dumps(cue_sheet, indent=1))
    print(json.dumps({"measured": hist[-1], "cues": len(T.cues)}, indent=1))


if __name__ == "__main__":
    main()
