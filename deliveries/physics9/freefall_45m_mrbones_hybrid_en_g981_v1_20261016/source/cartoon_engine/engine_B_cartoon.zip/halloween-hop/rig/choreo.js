// Mr. Bones' performance as rig controls: controls(B) for any beat B (pure, deterministic).
// Conventions:
//  * planted feet are world contacts (ball and heel fixed); swivels pivot on the ball with the heel up;
//  * every flight is ballistic with the one gravity of the film (timeline rig.gravity);
//  * time on the beat: B = t * bpm / 60; drawings are sampled on twos by the caller.
import { add, sub, scl, mv, mm, ry, rx, norm, lerp3, fapp, finv, fmul, clamp } from '../lib/m3.js';
import { DIM } from './model.js';

const smooth = (u) => { u = clamp(u, 0, 1); return u * u * (3 - 2 * u); };
const prog = (x, a, b) => clamp((x - a) / (b - a), 0, 1);
const easeOut = (u) => 1 - (1 - clamp(u, 0, 1)) ** 3;
const easeIn = (u) => clamp(u, 0, 1) ** 3;
const easeIO = (u) => { u = clamp(u, 0, 1); return u < 0.5 ? 4 * u * u * u : 1 - (-2 * u + 2) ** 3 / 2; };
const lerp = (a, b, u) => a + (b - a) * u;
const frac = (x) => x - Math.floor(x);

// blend two control sets (numbers lerp; target-spec lists merge with weights; others switch at 1/2)
export function mix(a, b, u) {
  if (u <= 0) return a;
  if (u >= 1) return b;
  if (typeof a === 'number' && typeof b === 'number') return a + (b - a) * u;
  if (Array.isArray(a) && Array.isArray(b)) {
    if ((a[0] && typeof a[0] === 'object' && 'space' in a[0]) || (b[0] && typeof b[0] === 'object' && 'space' in b[0])) {
      return [...a.map((x) => ({ ...x, w: (x.w ?? 1) * (1 - u) })), ...b.map((x) => ({ ...x, w: (x.w ?? 1) * u }))];
    }
    if (a.length === b.length) return a.map((x, i) => mix(x, b[i], u));
    return u < 0.5 ? a : b;
  }
  if (a && b && typeof a === 'object' && typeof b === 'object' && !a.R && !b.R) {
    const o = {};
    for (const k of new Set([...Object.keys(a), ...Object.keys(b)])) {
      if (k in a && k in b) o[k] = mix(a[k], b[k], u);
      else o[k] = u < 0.5 ? a[k] : b[k];
    }
    return o;
  }
  return u < 0.5 ? a : b;
}

export function makeChoreo(tl) {
  const E = tl.events, R = tl.rig;
  const spb = 60 / tl.music.bpm, g = R.gravity;
  const T = (beats) => beats * spb;
  const dps = tl.music.drawingsPerSecond;
  const alt = (B) => (Math.floor(T(B) * dps + 1e-9) % 2 === 0 ? 1 : -1); // flips every drawing
  const TURN = 0.36, HOMEX = 20, REST_Y = R.pop.restY;
  const sn = (s) => (s < 0 ? 'R' : 'L');

  // ---------------------------------------------------------------- building blocks
  // plant a foot by its ankle-on-ground point (flat foot); roll lifts the heel about the ball
  function plantAnkle(s, ax, az, heading, kneeOut = 0.25) {
    const ball = [ax + Math.sin(heading) * DIM.ballZ, 0, az + Math.cos(heading) * DIM.ballZ];
    return plantBall(s, ball, heading, 0, 0, kneeOut);
  }
  function plantBall(s, ball, heading, roll = 0, toe = 0, kneeOut = 0.25) {
    const Rf = mm(ry(heading), rx(roll));
    const a = sub(ball, mv(Rf, [0, -13.5, 27]));
    return { a, heading, pitch: roll, toe, plantW: 1, contact: roll > 1e-6 ? 'ball' : 'flat', ball, kneeOut };
  }
  const freeFoot = (a, heading, pitch = 0, toe = 0.1, kneeOut = 0.3) => ({ a, heading, pitch, toe, plantW: 0, contact: 'none', ball: null, kneeOut });
  const home = (s, kneeOut) => plantAnkle(s, s * HOMEX, 0, s * TURN, kneeOut);
  const homeBall = (s) => home(s).ball;
  const wide = (s, kneeOut = 0.45) => plantAnkle(s, s * 34, 4, s * 0.5, kneeOut);

  const cP = (p, w = 1) => ({ space: 'chest', p, w });
  const pP = (p, w = 1) => ({ space: 'pelvis', p, w });
  const hP = (p, w = 1) => ({ space: 'head', p, w });
  const HANG = (s) => [s * 47, -93, 8];
  const hang = (s, o = {}) => ({ specs: [cP(HANG(s))], curl: [0.2, 0.25, 0.3, 0.35], spread: 0.35, pron: 0.25, flex: 0.1, dev: 0, ...o });
  const onHip = (s, o = {}) => ({ specs: [pP([s * 47, 22, 8])], pole: [s * 1, -0.1, -0.35], pron: 0.9, flex: -0.45, curl: [0.4, 0.55, 0.6, 0.65], spread: 0.1, ...o });
  const jazz = (B) => ({ curl: [0.02, 0, 0, 0], spread: 1, dev: 0.12 * alt(B) });

  function base(B) {
    const ph = frac(B);
    return {
      visible: true, clip: false,
      pelvis: [0, REST_Y - 2 * Math.sin(Math.PI * ph) ** 2, 0], pelvisRot: [0, 0, 0], yaw: 0,
      spine: [0, 0, 0], neck: [0, 0, 0], head: [0, 0, 0], jaw: 0.12, look: [0, 0], pupil: 1,
      shrug: [0, 0], prot: [0, 0],
      leg: [home(-1), home(1)], arm: [hang(-1), hang(1)],
      hat: { mode: 'head' }, explode: 0, headToss: null, bowtie: true,
    };
  }

  // ---------------------------------------------------------------- 1 underground: hands claw out of the grave
  const wristUnder = (B, s) => {
    const r = easeOut(prog(B, R.hands[0], R.hands[1]));
    return [s * (30 + 5 * Math.sin(2 * Math.PI * 0.75 * B + s)), lerp(-125, -14, r) + 3 * Math.sin(2 * Math.PI * B + s), 12];
  };
  // while the hands claw up through the soil the body climbs behind them (arms stay reaching up)
  const climbUnder = (B) => R.pop.fromY - 80 * (1 - easeOut(prog(B, R.hands[0], R.hands[1])));
  function underground(B) {
    const c = base(B);
    c.visible = B >= R.hands[0];
    c.clip = true;
    c.pelvis = [0, climbUnder(B), 0];
    c.head = [-0.35, 0, 0];
    c.jaw = 0.35 + 0.2 * alt(B);
    c.leg = [-1, 1].map((s) => freeFoot(add(c.pelvis, [s * 20, -112, 6]), s * 0.2, 0.5, 0.2, 0.4));
    c.arm = [-1, 1].map((s) => ({
      specs: [{ space: 'world', p: wristUnder(B, s) }], pole: [s * 1, 0, -0.4], flex: -0.25, pron: 0.1,
      curl: [0, 1, 2, 3].map((k) => 0.32 + 0.38 * Math.sin(2 * Math.PI * (B * 1.5 + k * 0.22) + s)), spread: 0.9,
    }));
    return c;
  }

  // ---------------------------------------------------------------- 2 pop out (ballistic) and 3 landing
  const pop = R.pop;
  const popT = T(pop.land - pop.launch);
  const popV0 = (pop.landY - pop.fromY + 0.5 * g * popT * popT) / popT;
  const popVland = popV0 - g * popT;
  const absorbY = (B) => {
    const tau = T(B - pop.land), A = pop.landY - REST_Y, Bc = popVland + pop.damp * A;
    return REST_Y + Math.exp(-pop.damp * tau) * (A + Bc * tau);
  };
  const UPREL = (s) => [s * 40, 232, 16], OUTREL = (s) => [s * 84, 118, 22], HANGREL = (s) => [s * 47, 8, 17];
  function popOut(B) {
    const c = base(B);
    const tau = T(B - pop.launch), u = clamp((B - pop.launch) / (pop.land - pop.launch), 0, 1);
    c.clip = B < pop.launch + 0.75;
    c.pelvis = [0, pop.fromY + popV0 * tau - 0.5 * g * tau * tau, 0];
    const k = Math.sin(Math.PI * u) ** 1.2;
    c.leg = [-1, 1].map((s) => {
      const rel = add(lerp3([s * 20, -112, 6], [s * 20, -119.5, 0], u), scl([s * 6, 52, 26], k));
      return freeFoot(add(c.pelvis, rel), lerp(s * 0.2, s * TURN, u), 0.6 * (1 - smooth(prog(u, 0.7, 0.97))), 0.2 * (1 - u), 0.45);
    });
    c.arm = [-1, 1].map((s) => {
      const w0 = sub(wristUnder(pop.launch, s), [0, pop.fromY, 0]);
      const p = u < 0.45 ? lerp3(w0, UPREL(s), easeOut(u / 0.45)) : lerp3(UPREL(s), OUTREL(s), easeIO((u - 0.45) / 0.55));
      return { specs: [pP(p)], pole: [s * 1, 0, -0.4], ...jazz(B), flex: -0.2, pron: 0.1 };
    });
    c.jaw = 0.85; c.head = [-0.12, 0, 0]; c.look = [0, 0.6]; c.pupil = 1.3;
    return c;
  }
  function land(B) {
    const c = base(B);
    const y = absorbY(B);
    c.pelvis = [0, y, 0];
    const dip = clamp((REST_Y - y) / 20, -0.3, 1);
    c.spine = [0.3 * dip, 0.05 * alt(B) * Math.exp(-3 * Math.max(0, B - pop.land)), 0];
    c.head = [0.2 * dip, 0, 0];
    c.leg = [home(-1, 0.5), home(1, 0.5)];
    const u = prog(B, pop.land, pop.land + 0.7);
    c.arm = [-1, 1].map((s) => ({ ...hang(s), specs: [pP(lerp3(OUTREL(s), HANGREL(s), easeIO(u)))], pole: [s * 1, 0, -0.5], spread: lerp(1, 0.35, u) }));
    c.jaw = 0.4 + 0.15 * alt(B);
    return c;
  }

  // ---------------------------------------------------------------- 4 hat tip (bow), 5 wave at the pumpkin
  const [h0, hGrab, hUp, hHold, hRel, hDown] = R.hatTip;
  const GRIP = [-44, 42, 17], LIFT = [-44, 74, 31];
  function hatTip(B) {
    const c = base(B);
    c.pelvis = [0, B < pop.land + 2.5 ? absorbY(B) : REST_Y, 0];
    const bow = Math.sin(Math.PI * prog(B, hGrab, hRel)) ** 0.8;
    c.spine = [0.34 * bow, 0, -0.05 * bow];
    c.neck = [0.2 * bow, 0, 0];
    c.head = [0.12 * bow - 0.05, 0.08 * bow, 0];
    c.jaw = 0.18 + 0.2 * bow;
    // right hand: reach the brim, lift the hat, hold, put it back, let go
    let spec;
    if (B < hGrab) spec = [cP(HANG(-1), 1 - easeIO(prog(B, h0, hGrab))), hP(GRIP, easeIO(prog(B, h0, hGrab)) + 1e-9)];
    else if (B < hUp) spec = [hP(lerp3(GRIP, LIFT, easeIO(prog(B, hGrab, hUp))))];
    else if (B < hHold) spec = [hP(add(LIFT, [0, 3 * Math.sin(Math.PI * prog(B, hUp, hHold)), 4]))];
    else if (B < hRel) spec = [hP(lerp3(add(LIFT, [0, 0, 4]), GRIP, easeIO(prog(B, hHold, hRel))))];
    else spec = [hP(GRIP, 1 - easeIO(prog(B, hRel, hDown)) + 1e-9), cP(HANG(-1), easeIO(prog(B, hRel, hDown)))];
    c.arm[0] = { specs: spec, pole: [-1, -0.2, -0.6], flex: 0.35, pron: 0.35, curl: [0.5, 0.75, 0.8, 0.85], spread: 0.1 };
    // left hand on the heart (sternum)
    const hl = Math.sin(Math.PI * prog(B, h0, hDown)) ** 0.6;
    c.arm[1] = { ...hang(1), specs: [cP(HANG(1), 1 - hl + 1e-9), cP([26, -4, 30], hl)], pron: lerp(0.25, 0.95, hl), flex: lerp(0.1, 0.35, hl), curl: [0.2, 0.15, 0.15, 0.2] };
    c.hat = { mode: 'head' };
    if (B >= hGrab && B < hRel) c.hat = { mode: 'hand', hand: 'handR', rel: null };
    else if (B >= hRel && B < hRel + 0.25) c.hat = { mode: 'blend', u: easeIO(prog(B, hRel, hRel + 0.25)), from: null };
    return c;
  }
  function wave(B) {
    const c = base(B);
    const u = smooth(prog(B, R.wave[0], R.wave[0] + 0.5));
    c.pelvisRot = [0, -0.18 * u, 0];
    c.spine = [0.03, 0, -0.12 * u];
    c.head = [-0.04, -0.45 * u, 0.06 * Math.sin(Math.PI * B)];
    c.look = [-0.8 * u, 0];
    c.jaw = 0.2 + 0.25 * Math.sin(Math.PI * frac(B * 2)) ** 2;
    c.arm[0] = { specs: [cP([-70, 64, 28])], pole: [-1, -0.4, -0.3], ...jazz(B), dev: 0.42 * Math.sin(2 * Math.PI * 2 * (B - R.wave[0])), flex: -0.15, pron: 0.05,
      curl: [0, 1, 2, 3].map((k) => 0.12 + 0.2 * Math.sin(2 * Math.PI * 2 * (B - R.wave[0]) - k * 0.6)) };
    c.arm[1] = onHip(1);
    return c;
  }

  // ---------------------------------------------------------------- Charleston kicks (used twice)
  function kicks(B, o = {}) {
    const c = base(B);
    const n = Math.floor(B), ph = frac(B);
    const sk = n % 2 === 0 ? -1 : 1; // kicking side this beat
    const k = Math.sin(Math.PI * ph) ** 1.5;
    const back = o.back ? o.back(B) : false;
    c.pelvis = [-sk * 6 * Math.sin(Math.PI * ph) + (o.dx || 0), 112 + 14 * Math.sin(Math.PI * ph) ** 2, 0];
    c.pelvisRot = [0.04, (o.yaw || 0), sk * 0.06 * k];
    c.spine = [0.08, -sk * 0.1 * k, sk * 0.14 * k + (o.twist || 0)];
    c.head = [0.1 * Math.sin(Math.PI * ph) ** 2 - 0.05, -(o.yaw || 0) * 0.6, -sk * 0.1 * k];
    c.jaw = 0.15 + 0.35 * Math.sin(Math.PI * ph) ** 2;
    const peak = back ? [sk * 14, 46, -40] : (o.peak ? o.peak(sk) : [sk * 26, 58, 44]);
    c.leg = [-1, 1].map((s) => {
      if (s !== sk) return home(s, 0.3);
      const a = add([s * HOMEX, 13.5, 0], scl(peak, k));
      return { ...freeFoot(a, s * (TURN + 0.2 * k), 0.95 * k, 0.25 * k, back ? 0.1 : 0.35), contact: k < 1e-9 ? 'flat' : 'none', plantW: k < 1e-9 ? 1 : 0 };
    });
    c.arm = [-1, 1].map((s) => {
      if (o.high) {
        const p = [s * (64 + 8 * k), 92 + 12 * k, 22];
        return { specs: [cP(p)], pole: [s, -0.3, -0.4], ...jazz(B), flex: -0.2, pron: 0.1 };
      }
      const front = s === -sk;
      const tgt = front ? [s * 56, 30, 50] : [s * 56, -66, -34];
      return { ...hang(s), specs: [cP(lerp3(HANG(s), tgt, k))], spread: 0.35 + 0.65 * k, curl: [0.25 * (1 - k), 0.25 * (1 - k), 0.25 * (1 - k), 0.25 * (1 - k)], pron: front ? 0.1 : 0.4 };
    });
    return c;
  }

  // ---------------------------------------------------------------- swivel: heels in/out, knees knock, hands cross
  const [sw0, sw1] = R.swivel;
  const knockAt = []; for (let b = sw0 + 1.5; b < sw1; b += 2) knockAt.push(b);
  function swivel(B) {
    const c = base(B);
    // ease into and out of the crouch over a whole beat: the skull must never drop faster than g (the hat would lift off)
    const env = smooth(prog(B, sw0, sw0 + 1)) * (1 - smooth(prog(B, sw1 - 1, sw1)));
    const osc = Math.sin(Math.PI * (B - sw0));
    // crossing state flips each time the knees knock together
    let cross = 0;
    knockAt.forEach((kb, i) => { const st = smooth(prog(B, kb - 0.35, kb + 0.35)); cross = i % 2 === 0 ? cross + st : cross - st; });
    cross = clamp(cross, 0, 1);
    const roll = 0.3 * env;
    // while the arms are crossed the knees open less (the hands must still reach the far knee)
    const open = osc * env * (1 - 0.8 * cross);
    c.leg = [-1, 1].map((s) => plantBall(s, homeBall(s), s * (TURN + 0.42 * open), roll, 0, 0.3 + 0.75 * open));
    c.pelvis = [0, lerp(REST_Y, 86 + 5 * Math.sin(Math.PI * (B - sw0)) ** 2, env), lerp(0, -14, env)];
    c.pelvisRot = [0.36 * env, 0, 0];
    c.spine = [0.92 * env, 0, 0];
    c.neck = [-0.62 * env, 0, 0];
    c.head = [-0.2 * env, 0, 0.12 * Math.sin(Math.PI * (B - sw0) / 2) * env];
    c.jaw = 0.2 + 0.4 * Math.sin(Math.PI * frac(B)) ** 2;
    // reaching across: both shoulder girdles protract (the scapulae slide forward round the ribcage)
    c.prot = [0.62 * cross * env, 0.62 * cross * env];
    c.arm = [-1, 1].map((s) => {
      const own = sn(s), other = sn(-s);
      // own knee: on top of the kneecap; far knee: its inner side (the forearms stack, one over the other)
      const onOwn = [0, 11, 12], onFar = [s * 12, 12 + (s < 0 ? 4 : -1), 13 + (s < 0 ? 5 : -2)];
      const onKnees = [{ space: 'knee', side: own, p: onOwn, w: 1 - cross + 1e-9 }, { space: 'knee', side: other, p: onFar, w: cross + 1e-9 }];
      // the hands only find the knees once the body has bent down to them
      const hw = env ** 3;
      const specs = env >= 1 ? onKnees : [...onKnees.map((x) => ({ ...x, w: x.w * hw + 1e-9 })), cP(HANG(s), 1 - hw + 1e-9)];
      return { specs, pole: [s * 1.1, 0.3, -0.5], flex: 0.25, pron: 0.55, curl: [0.4, 0.5, 0.55, 0.6], spread: 0.25 };
    });
    return c;
  }

  // ---------------------------------------------------------------- shimmy
  function shimmy(B) {
    const c = base(B);
    const a = alt(B);
    const env = smooth(prog(B, R.shimmy[0], R.shimmy[0] + 0.5));
    c.pelvis = [6 * Math.sin(Math.PI * (B - R.shimmy[0]) / 2), 120 + 3 * Math.sin(Math.PI * frac(B)) ** 2, 0];
    c.shrug = [0.16 * (a > 0 ? 1 : -0.3) * env, 0.16 * (a < 0 ? 1 : -0.3) * env];
    c.prot = [0.2 * a * env, -0.2 * a * env];
    c.spine = [0.02, 0.12 * Math.sin(Math.PI * (B - R.shimmy[0]) / 2), 0.07 * a * env];
    c.neck = [0, -0.2 * Math.sin(Math.PI * (B - R.shimmy[0])), 0];
    c.head = [0, 0, 0.12 * Math.sin(Math.PI * (B - R.shimmy[0]))];
    c.jaw = 0.15 + 0.15 * (a > 0 ? 1 : 0);
    c.arm = [-1, 1].map((s) => ({ specs: [cP(lerp3(HANG(s), [s * 106, 14, 22], env))], pole: [s, -0.2, -0.6], ...jazz(B), dev: 0.22 * a, flex: -0.25, pron: 0.1 }));
    return c;
  }

  // ---------------------------------------------------------------- mallet: pull a spare femur out of the ribcage, play, pocket it
  const [pm0, pmIn, pmOut] = R.pullMallet;
  const [x0, x1] = R.xylo;
  const H = E.xyloHits;
  const hits = []; for (let k = 0, b = H.from; b <= H.to + 1e-9; b += H.every, k++) hits.push({ b, rib: R.ribMap[H.ribs[k]] });
  const OFF = 7.2 + 2.7; // mallet-head radius + rib radius: surface contact
  const INSIDE = [8, -6, 12];
  const INSIDE_HEAD = [2, -2, 14]; // where the mallet head sits while the hand is inside the ribcage
  const rest = (o = {}) => ({ pron: 0.35, flex: 0.1, dev: -0.2, curl: [0.85, 0.9, 0.95, 1.0], spread: 0.05, pole: [0.7, -1, -0.45], ...o });
  const ready = (w = 1) => ({ strike: hits[0].rib, lift: 1, w });
  function xyloBody(B, c) {
    c.pelvis = [0, 122 - 2 * Math.sin(Math.PI * frac(B)) ** 2, 0];
    c.spine = [0.1, 0.06, 0.12];
    c.neck = [0.22, 0, 0];
    c.head = [0.18, 0.28, -0.06];
    c.look = [0.7, 0.9];
    c.arm[0] = onHip(-1);
    return c;
  }
  function pullMallet(B) {
    const c = xyloBody(B, base(B));
    const u1 = easeIO(prog(B, pm0, pmIn)), u2 = easeIO(prog(B, pmIn, pmOut));
    if (B < pmIn) c.arm[1] = { ...rest(), specs: [cP(HANG(1), 1 - u1 + 1e-9), cP(INSIDE, u1 + 1e-9)], curl: [0.4, 0.5, 0.5, 0.5] };
    else c.arm[1] = { ...rest(), holdMallet: true, mallet: [{ target: [cP(INSIDE_HEAD)], w: 1 - u2 }, ready(u2)] };
    c.jaw = 0.25 + 0.3 * Math.sin(Math.PI * prog(B, pm0, pmOut));
    return c;
  }
  function xylo(B) {
    const c = xyloBody(B, base(B));
    let spec;
    if (B < hits[0].b) {
      const u = easeIO(prog(B, x0, hits[0].b));
      spec = [{ strike: hits[0].rib, lift: 1 - u * u }];
    } else if (B >= hits[hits.length - 1].b) {
      const u = prog(B, hits[hits.length - 1].b, x1);
      spec = [{ strike: hits[hits.length - 1].rib, lift: Math.sin(Math.PI / 2 * u) }];
    } else {
      let k = 0; while (k < hits.length - 2 && B >= hits[k + 1].b) k++;
      const u = (B - hits[k].b) / (hits[k + 1].b - hits[k].b);
      // fast attack into the strike, quick rebound off the rib (a mallet bounces off the bar)
      const lift = Math.sin(Math.PI * Math.pow(u, 0.8));
      const m = smooth(u);
      spec = [{ strike: hits[k].rib, lift, w: 1 - m }, { strike: hits[k + 1].rib, lift, w: m }];
    }
    c.arm[1] = { ...rest(), holdMallet: true, specs: [cP(INSIDE)], mallet: spec };
    const since = hits.reduce((m, h) => (B >= h.b ? Math.min(m, B - h.b) : m), 9);
    c.jaw = 0.18 + 0.45 * Math.exp(-6 * since);
    c.pupil = 1 + 0.25 * Math.exp(-6 * since);
    return c;
  }
  // rib ringing after each strike (left ribs): damped 6 Hz vibration, sampled on twos it alternates
  const RING_A = 0.11, RING_F = 6, RING_D = 5;
  function ring(i, s, B) {
    if (s < 0) return 0;
    let a = 0;
    for (const h of hits) {
      if (h.rib !== i || B < h.b) continue;
      const tau = T(B - h.b);
      a += RING_A * Math.exp(-RING_D * tau) * Math.cos(2 * Math.PI * RING_F * tau);
    }
    return a;
  }
  const [pk0, pkIn, pkOut] = R.pocketMallet;
  function pocket(B) {
    const c = xyloBody(B, base(B));
    const u1 = easeIO(prog(B, pk0, pkIn)), u2 = easeIO(prog(B, pkIn, pkOut));
    const lastRib = hits[hits.length - 1].rib;
    if (B < pkIn) c.arm[1] = { ...rest(), holdMallet: true, mallet: [{ strike: lastRib, lift: 1, w: 1 - u1 }, { target: [cP(INSIDE_HEAD)], w: u1 }] };
    else c.arm[1] = { ...rest(), specs: [cP(INSIDE, 1 - u2 + 1e-9), cP(HANG(1), u2 + 1e-9)], curl: [0.4, 0.5, 0.5, 0.5] };
    return c;
  }

  // ---------------------------------------------------------------- finale: high kicks, hips sway
  function finale(B) {
    if (B < 65) {
      const c = base(B);
      const u = easeIO(prog(B, R.finale[0], 65));
      c.arm = [-1, 1].map((s) => ({ specs: [cP(lerp3(HANG(s), [s * 64, 92, 22], u))], pole: [s, -0.3, -0.4], ...jazz(B), flex: -0.2 * u, pron: 0.1 }));
      c.pelvis = [0, lerp(REST_Y, 112, u), 0];
      return c;
    }
    return kicks(B, { high: true, yaw: 0.32 * Math.sin(Math.PI * (B - 65) / 2), peak: (sk) => [sk * 30, 70, 50] });
  }

  // ---------------------------------------------------------------- head toss, hop, ta-da
  const TS = R.toss;
  const tossT = T(TS.catch - TS.launch);
  let tossFrames = null; // {launch, land} head-attach frames, set by the director after a first evaluation
  function toss(B) {
    const c = base(B);
    const ph = frac(B);
    c.pelvis = [0, 116 + 8 * Math.sin(Math.PI * ph) ** 2, 0];
    c.leg = [home(-1, 0.4), home(1, 0.4)];
    c.spine = [0.04, 0, 0];
    c.jaw = 0.35 + 0.3 * alt(B);
    if (B >= TS.launch && B < TS.catch && tossFrames) {
      c.headToss = { u: (B - TS.launch) / (TS.catch - TS.launch), T: tossT, g, launch: tossFrames.launch, land: tossFrames.land, turns: TS.turns };
    }
    // arms: fling up on the throw, reach under the falling skull, clasp it on the catch, let go
    c.arm = [-1, 1].map((s) => {
      const up = [s * 34, 112, 22];
      const fl = easeOut(prog(B, TS.launch - 0.25, TS.launch + 0.2));
      const reach = easeIO(prog(B, TS.catch - 0.3, TS.catch)); // late: the skull is out of reach until it drops back
      const letGo = easeIO(prog(B, TS.catch + 0.3, TS.catch + 0.5));
      const clasp = hP([s * 42, 20, 4]);
      const specs = [cP(lerp3(HANG(s), up, fl), (1 - reach) * (1 - letGo) + 1e-9), { ...clasp, w: reach * (1 - letGo) + 1e-9 }, cP(HANG(s), letGo + 1e-9)];
      return { specs, pole: [s * 1, -0.3, -0.5], flex: 0.15, pron: lerp(0.1, 0.85, reach), curl: [0.3, 0.35, 0.35, 0.4], spread: 0.6 };
    });
    return c;
  }
  const HOP = R.hop, hopT = T(HOP.land - HOP.launch);
  function hop(B) {
    const c = base(B);
    const u = prog(B, HOP.launch, HOP.land), tau = u * hopT;
    c.pelvis = [0, lerp(116, 122, u) + 0.5 * g * tau * (hopT - tau), 0];
    c.leg = [-1, 1].map((s) => {
      const a0 = home(s).a, a1 = wide(s).a;
      const a = add(lerp3(a0, a1, u), [0, 19 * Math.sin(Math.PI * u), 0]);
      return freeFoot(a, lerp(s * TURN, s * 0.5, u), 0.3 * Math.sin(Math.PI * u), 0.1, 0.45);
    });
    c.arm = [-1, 1].map((s) => ({ specs: [cP(lerp3(HANG(s), [s * 80, 112, 22], easeOut(u)))], pole: [s, -0.3, -0.4], ...jazz(B), flex: -0.2, pron: 0.1 }));
    c.jaw = 0.45;
    return c;
  }
  // plié on landing: velocity-matched damped curve (like the grave pop)
  const hopVland = (122 - 116) / hopT - 0.5 * g * hopT;
  const tadaY = (B) => { const tau = T(B - HOP.land), A = 122 - 118, c_ = 12, Bc = hopVland + c_ * A; return 118 + Math.exp(-c_ * tau) * (A + Bc * tau); };
  function tada(B) {
    const c = base(B);
    c.pelvis = [0, tadaY(B), 0];
    c.leg = [wide(-1), wide(1)];
    c.arm = [-1, 1].map((s) => ({ specs: [cP([s * 80, 112, 22])], pole: [s, -0.3, -0.4], ...jazz(B), dev: 0.15 * alt(B), flex: -0.2, pron: 0.1 }));
    c.head = [-0.06, 0, 0.2];
    c.jaw = 0.45;
    return c;
  }

  // ---------------------------------------------------------------- take, burst apart, tremble
  const [ex0, ex1, ex2, ex3] = R.explode;
  const burst = (B) => (B < ex0 ? 0 : B < ex1 ? easeOut(prog(B, ex0, ex1)) : B < ex2 ? 1 + 0.08 * prog(B, ex1, ex2) : 1.08 * (1 - easeIn(prog(B, ex2, ex3))));
  function take(B) {
    const c = base(B);
    const u = easeOut(prog(B, R.take, R.take + 0.15));
    c.pelvis = [0, lerp(tadaY(R.take), 128, u), 0];
    c.leg = [wide(-1), wide(1)];
    c.arm = [-1, 1].map((s) => ({ specs: [cP(lerp3([s * 80, 112, 22], [s * 46, 128, 14], u))], pole: [s, -0.2, -0.3], curl: [0, 0, 0, 0], spread: 1, flex: -0.3, pron: 0.1 }));
    c.jaw = 1.0; c.pupil = 2.4; c.head = [-0.25, 0, 0]; c.look = [0, 0.3];
    c.explode = burst(B);
    return c;
  }
  function tremble(B) {
    const c = base(B);
    const a = alt(B);
    c.pelvis = [0, 106, 0];
    c.leg = [-1, 1].map((s) => ({ ...wide(s, -0.5 + 0.4 * a) }));
    c.arm = [-1, 1].map((s) => ({ specs: [cP([s * -24, 4, 34])], pole: [s, -0.6, -0.2], curl: [0.6, 0.65, 0.7, 0.7], spread: 0.1, flex: 0.2, pron: 0.9, dev: 0.1 * a }));
    c.spine = [0.25, 0.03 * a, 0];
    c.head = [0.05, -0.55, 0.05 * a];
    c.look = [-1, 0.2]; c.pupil = 1.6;
    c.jaw = 0.3 + 0.2 * a;
    return c;
  }

  // ---------------------------------------------------------------- scram: crouch, jump, drop into the grave
  const SC = R.scram;
  const Tc = T(SC.crouch[1] - SC.crouch[0]) * 0 + T(SC.launch - SC.crouch[1]);
  const crouchDepth = 28;
  const scV0 = (2 * crouchDepth) / Tc; // C1-continuous extension y = y0 + d (tau/Tc)^2 ends at this speed
  const apexB = SC.launch + scV0 / g / spb;
  // the contacts are placed on drawings (the animator's "hit on the drawing"): the grave depth is the
  // one at which a body launched at scV0 under g reaches the bottom exactly at thudAt
  const thudB = SC.thudAt, thudTau = T(thudB - SC.launch);
  const graveBottomY = REST_Y + scV0 * thudTau - 0.5 * g * thudTau * thudTau;
  let hatHang = null; // hat frame at the apex, set by the director
  function scram(B) {
    const c = base(B);
    c.leg = [wide(-1), wide(1)];
    if (B < SC.crouch[1]) {
      c.pelvis = [0, lerp(106, REST_Y - crouchDepth, easeIO(prog(B, SC.crouch[0], SC.crouch[1]))), 0];
      c.arm = [-1, 1].map((s) => ({ ...hang(s), specs: [cP([s * 52, -80, -34])] }));
      c.spine = [0.35, 0, 0]; c.head = [-0.2, 0, 0];
    } else if (B < SC.launch) {
      const tau = T(B - SC.crouch[1]);
      c.pelvis = [0, REST_Y - crouchDepth + crouchDepth * (tau / Tc) ** 2, 0];
      const u = prog(B, SC.crouch[1], SC.launch);
      c.arm = [-1, 1].map((s) => ({ ...hang(s), specs: [cP(lerp3([s * 52, -80, -34], [s * 20, 120, 6], easeIn(u)))] }));
      c.spine = [0.35 * (1 - u), 0, 0];
    } else {
      const tau = T(B - SC.launch);
      c.pelvis = [0, REST_Y + scV0 * tau - 0.5 * g * tau * tau, 0];
      const u = clamp((B - SC.launch) / 0.5, 0, 1);
      c.leg = [-1, 1].map((s) => {
        const rel = lerp3(sub(wide(s).a, [0, REST_Y, 0]), [s * 12, -118, 2], easeOut(u));
        return freeFoot(add(c.pelvis, rel), s * 0.15, 0.8 * u, 0.2, 0.2);
      });
      c.arm = [-1, 1].map((s) => ({ ...hang(s), specs: [cP([s * 20, 120, 6])], curl: [0, 0, 0, 0], spread: 0.2, pole: [s, -0.2, -0.3] }));
      c.clip = true;
      c.pupil = 1.8; c.jaw = 0.9;
      if (B >= apexB) c.hat = { mode: 'world', F: hatHang ? hatAt(B) : null };
    }
    c.visible = B < thudB;
    return c;
  }
  // the hat hangs where the head left it, then falls with the same gravity
  // the hat hangs until it must start falling to land on the grave's lip exactly at hatPlopAt
  let hangEnd = null;
  function hatAt(B) {
    if (B < hangEnd) return hatHang;
    const tau = T(B - hangEnd);
    return { R: hatHang.R, t: add(hatHang.t, [0, -0.5 * g * tau * tau, 0]) };
  }
  const hatPlopB = () => SC.hatPlopAt;

  // ---------------------------------------------------------------- the dope sheet
  const SEG = [
    { b0: -1e9, f: underground, blend: 0 },
    { b0: pop.launch, f: popOut, blend: 0 },
    { b0: pop.land, f: land, blend: 0 },
    { b0: h0, f: hatTip, blend: 0.3 },
    { b0: R.wave[0], f: wave, blend: 0.3 },
    { b0: R.kicks[0], f: (B) => kicks(B, { back: (b) => b >= 41 && b < 44 }), blend: 0.4 },
    { b0: R.swivel[0], f: swivel, blend: 0.3 },
    { b0: R.shimmy[0], f: shimmy, blend: 0.4 },
    { b0: pm0, f: pullMallet, blend: 0.3 },
    { b0: x0, f: xylo, blend: 0 },
    { b0: pk0, f: pocket, blend: 0.1 },
    { b0: R.finale[0], f: finale, blend: 0.2 },
    { b0: TS.launch, f: toss, blend: 0.3 },
    { b0: HOP.launch, f: hop, blend: 0 },
    { b0: HOP.land, f: tada, blend: 0 },
    { b0: R.take, f: take, blend: 0.12 },
    { b0: R.tremble[0], f: tremble, blend: 0.25 },
    { b0: SC.crouch[0], f: scram, blend: 0.1 },
  ];
  function controls(B) {
    let i = 0;
    while (i < SEG.length - 1 && B >= SEG[i + 1].b0) i++;
    let c = SEG[i].f(B);
    const s = SEG[i];
    if (s.blend > 0 && i > 0 && B < s.b0 + s.blend / 2) c = mix(SEG[i - 1].f(B), c, smooth((B - (s.b0 - s.blend / 2)) / s.blend));
    const nx = SEG[i + 1];
    if (nx && nx.blend > 0 && B >= nx.b0 - nx.blend / 2) c = mix(c, nx.f(B), smooth((B - (nx.b0 - nx.blend / 2)) / nx.blend));
    // headToss must never be blended (it is a pure function of the flight phase)
    if (B >= TS.launch && B < TS.catch && tossFrames) c.headToss = toss(B).headToss;
    else c.headToss = null;
    c.ring = (ri, side) => ring(ri, side, B);
    c.B = B;
    return c;
  }

  return {
    controls,
    hits,
    setTossFrames: (f) => { tossFrames = f; },
    setHatHang: (F) => { hatHang = F; hangEnd = SC.hatPlopAt - Math.sqrt((2 * F.t[1]) / g) / spb; },
    info: () => ({
      gravity: g,
      flights: [
        { name: 'pop out of the grave', what: 'pelvis', b0: pop.launch, b1: pop.land, v0: popV0 },
        { name: 'hop into the ta-da', what: 'pelvis', b0: HOP.launch, b1: HOP.land },
        { name: 'head toss', what: 'head', b0: TS.launch, b1: TS.catch },
        { name: 'dive into the grave', what: 'pelvis', b0: SC.launch, b1: thudB, v0: scV0 },
        { name: 'hat fall', what: 'hat', b0: hangEnd, b1: hatHang ? hatPlopB() : null },
      ],
      cues: {
        popLaunch: pop.launch, popLand: pop.land, tossLaunch: TS.launch, tossCatch: TS.catch, hopLand: HOP.land,
        burst: ex0, clatter: ex3, scramLaunch: SC.launch, apex: apexB, graveThud: thudB, hatPlop: hatHang ? hatPlopB() : null,
      },
      apexB, thudB, hangEnd, graveBottomY,
    }),
  };
}
