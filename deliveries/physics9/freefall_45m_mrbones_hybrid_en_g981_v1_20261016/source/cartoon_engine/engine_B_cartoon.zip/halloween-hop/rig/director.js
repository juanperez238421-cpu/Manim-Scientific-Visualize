// The skeleton's director: builds the model, the choreography and the secondary simulation,
// resolves the hand-offs that need a posed rig (head-toss frames, hat grab/release/hang),
// and poses the skeleton for any drawing. Pure (no DOM): used by the renderer and the QA.
import { buildModel, evaluate, ZERO_SEC } from './model.js';
import { makeChoreo } from './choreo.js';
import { simulate } from './secondary.js';
import { hatFrame } from './costume.js';
import { finv, fmul } from '../lib/m3.js';

export function makeDirector(tl) {
  const model = buildModel();
  const ch = makeChoreo(tl);
  const R = tl.rig, spb = 60 / tl.music.bpm;
  const t = (B) => B * spb;
  // head toss: launch/catch frames of the head as attached to the neck (the neck's own bobble is
  // switched off in that window, so these frames are exact with or without secondary motion)
  const at = (B, sec = ZERO_SEC) => { const c = ch.controls(B); return { c, ev: evaluate(model, c, sec) }; };
  ch.setTossFrames({ launch: at(R.toss.launch).ev.fr.headAttach, land: at(R.toss.catch).ev.fr.headAttach });
  // secondary simulation (with impulses: the hat pops on the take; the bones clatter back together)
  const impulses = [{ B: R.take, hat: 900, jaw: 2 }, { B: R.explode[3], jaw: 6, ribs: 1.6 }, { B: R.pop.land, ribs: 0.9 }];
  const sec = simulate(model, ch, tl, impulses);
  // hat hand-offs, captured from the posed rig with its secondary motion
  const [, hGrab, , , hRel] = R.hatTip;
  const g = at(hGrab, sec.at(t(hGrab)));
  const seat = hatFrame(g.ev, { hat: { mode: 'head' } }, sec.at(t(hGrab)));
  const grabRel = fmul(finv(g.ev.fr.handR), seat);
  const r = at(hRel, sec.at(t(hRel)));
  const releaseFrom = fmul(r.ev.fr.handR, grabRel);
  const apexB = ch.info().apexB;
  const a = at(apexB, sec.at(t(apexB)));
  ch.setHatHang(hatFrame(a.ev, { hat: { mode: 'head' } }, sec.at(t(apexB))));

  function pose(td) {
    const B = td / spb;
    const c = ch.controls(B);
    if (c.hat.mode === 'hand') c.hat = { ...c.hat, rel: grabRel };
    if (c.hat.mode === 'blend') c.hat = { ...c.hat, from: releaseFrom };
    const s = sec.at(td);
    const ev = evaluate(model, c, s);
    return { B, c, ev, sec: s };
  }
  return { model, choreo: ch, sec, pose, info: ch.info() };
}
