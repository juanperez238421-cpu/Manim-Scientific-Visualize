// Top hat and bow tie: placed by the 3-D rig, drawn in the 2-D period style.
import { fapp, fmul, ftr, frot, rz, mv, col } from '../lib/m3.js';
import { G } from '../lib/ink.js';
import { drawTopHat } from '../chars/skeleton.js';

// hat frame from the control state: on the head (with its secondary bounce), in a hand, or free
export function hatFrame(ev, c, sec) {
  const h = c.hat || { mode: 'head' };
  if (h.mode === 'none') return null;
  if (h.mode === 'world') return h.F;
  if (h.mode === 'hand') return fmul(ev.fr[h.hand], h.rel);
  const seat = fmul(ev.fr.head, fmul(ftr([2, 53.5 + Math.max(0, sec.hatLift || 0) + (h.lift || 0), -3]), frot(rz(-0.1 + (sec.hatTilt || 0) + (h.tilt || 0)))));
  if (h.mode === 'blend') {
    // easing back onto the head after a release: interpolate from the captured pose to the seat
    const u = h.u;
    return { R: seat.R, t: seat.t.map((x, i) => h.from.t[i] + (x - h.from.t[i]) * u) };
  }
  return seat;
}

export function costumeItems(ink, ev, c, sec, proj, S) {
  const items = [];
  const H = hatFrame(ev, c, sec);
  if (H) {
    const o = proj(H.t), up = proj(fapp(H, [0, 10, 0]));
    const rot = Math.atan2(up[0] - o[0], -(up[1] - o[1]));
    items.push({ z: o[2] + 4, draw: () => drawTopHat(ink, o[0], o[1], S * 0.92, rot) });
  }
  if (c.bowtie !== false && ev.fr.C7) {
    const p = fapp(ev.fr.C7, [0, 3, 12.5]);
    const o = proj(p), xr = proj(fapp(ev.fr.C7, [10, 3, 12.5]));
    const rot = Math.atan2(xr[1] - o[1], xr[0] - o[0]);
    const facing = mv(ev.fr.C7.R, [0, 0, 1])[2];
    if (facing > -0.2) {
      items.push({
        z: o[2] + 8,
        draw: () => {
          const ctx = ink.ctx;
          ctx.save();
          ctx.translate(o[0], o[1]); ctx.rotate(rot); ctx.scale(S * 0.62 * Math.max(0.35, facing), S * 0.62);
          ink.shape([[0, 0], [-18, -10], [-18, 10]], { fill: G.black, lw: 2.5 });
          ink.shape([[0, 0], [18, -10], [18, 10]], { fill: G.black, lw: 2.5 });
          ink.shape([[-12, -3], [-6, 0], [-12, 3]], { fill: G.dusk, ink: null, lw: 0 });
          ink.blob(0, 0, 5, 5, 0, { fill: G.black, lw: 2 });
          ctx.restore();
        },
      });
    }
  }
  return { items, hat: H };
}
