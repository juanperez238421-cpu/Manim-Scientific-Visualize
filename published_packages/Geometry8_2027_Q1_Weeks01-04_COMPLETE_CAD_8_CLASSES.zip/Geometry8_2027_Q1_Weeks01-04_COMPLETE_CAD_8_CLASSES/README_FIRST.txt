# GEOMETRY 8 · 2027 · QUARTER 1 · WEEKS 1–4

Eight verified ManimCE videos (two per week), authentic IJR crest,
Python lesson scenes, the full CAD base dependencies and QA evidence.

VIDEO DIRECTORY
Week 01 · 19–22 Jan 2027: course and point/line/ray/plane induction; sets.
Week 02 · 25–29 Jan 2027: line/plane relationships; spatial reasoning.
Week 03 · 01–05 Feb 2027: straightedge and compass; perpendicular/parallel constructions.
Week 04 · 08–12 Feb 2027: angle elements/classification; protractor practice.

All video files are full HD 1920 x 1080, H.264/yuv420p, 30 fps.
Week 01 Class 01 uses updated V4 intro; Week 01 Class 02 uses V2.
Weeks 02–04 use individually QA-reviewed V2 final versions.

Package structure:
01_Videos/Week_01 ... Week_04: 8 completed MP4s.
02_ManimCE_Source/: source paths, class scripts and original PNG crest.
03_QA_Evidence/: source contact sheets, metrics, QA ledgers.
04_Curriculum_Notes/: source-linked curriculum review and QA report.
SHA256SUMS.txt, manifest.json: verified MP4 integrity and inventory.

Source repository:
https://github.com/juanperez238421-cpu/Manim-Scientific-Visualize
Branch: geometry8-2027-w01-w04-eight-class-cad-release

Technical reproduction:
ManimCE 0.20.1, Docker recommended.
Render a source scene first with manim -pql and then manim -pqh.
Main classes in geometry8_six_classes_cad.py:
Geometry8W02_Class01_LinePlane
Geometry8W02_Class02_SpatialReasoning
Geometry8W03_Class01_Instruments
Geometry8W03_Class02_Constructions
Geometry8W04_Class01_Angles
Geometry8W04_Class02_Protractor

Notes: Original DOCX planner is not packaged here; the supplied
2027 dates and lesson scope are included in the curriculum notes.
