Physics 9 — Instituto Jorge Robledo — Q1 2027
8 Full-HD H.264 MP4 videos, 30 FPS
Week 1: Jan 19-22 | Week 2: Jan 25-29 | Week 3: Feb 1-5 | Week 4: Feb 8-12

The videos below are unchanged originals, sorted by teaching week.

Week_01/01_Physics_Induction.mp4  (8,389,282 bytes)
Week_01/02_Observation_and_Measurement.mp4  (5,314,080 bytes)
Week_02/03_SI_Units_and_Orders_of_Magnitude.mp4  (5,118,014 bytes)
Week_02/04_Scientific_Notation.mp4  (4,499,172 bytes)
Week_03/05_Conversions_and_Dimensional_Consistency.mp4  (5,540,390 bytes)
Week_03/06_Significant_Figures.mp4  (6,010,737 bytes)
Week_04/07_Vernier_and_Micrometer.mp4  (5,342,708 bytes)
Week_04/08_Measurement_and_Uncertainty_Lab.mp4  (7,892,416 bytes)

All videos rendered with ManimCE under the institutional CAD visual format.
These files preserve the original published video bytes, without transcoding.

